select sum(case when sex = '男' then 1 else 0 end) as '男生人数',sum(case when sex = '女' then 1 else 0 end) as '女生人数'
from tb_student;