TYPE=VIEW
query=select `t1`.`sname` AS `学生姓名`,max(`t2`.`score`) AS `最高分`,min(`t2`.`score`) AS `最低分`,(max(`t2`.`score`) - min(`t2`.`score`)) AS `分差` from (`db_exam`.`tb_student` `t1` join `db_exam`.`tb_score` `t2` on((`t1`.`stuid` = `t2`.`stuid`))) group by `t1`.`sname` order by min(`t2`.`score`) limit 5
md5=9fce9998715b15c573ad47f779d2da9d
updatable=0
algorithm=0
definer_user=root
definer_host=localhost
suid=2
with_check_option=0
timestamp=2024-12-04 02:30:01
create-version=1
source=select t1.sname as \'学生姓名\',max(t2.score) as \'最高分\',min(t2.score) as \'最低分\',max(t2.score) - min(t2.score) as \'分差\'\nfrom tb_student t1 join tb_score t2 on t1.stuid = t2.stuid\ngroup by t1.sname\norder by min(t2.score)\nlimit 5
client_cs_name=utf8mb4
connection_cl_name=utf8mb4_general_ci
view_body_utf8=select `t1`.`sname` AS `学生姓名`,max(`t2`.`score`) AS `最高分`,min(`t2`.`score`) AS `最低分`,(max(`t2`.`score`) - min(`t2`.`score`)) AS `分差` from (`db_exam`.`tb_student` `t1` join `db_exam`.`tb_score` `t2` on((`t1`.`stuid` = `t2`.`stuid`))) group by `t1`.`sname` order by min(`t2`.`score`) limit 5
