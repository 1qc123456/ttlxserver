select t1.sname as '学生姓名',round(avg(t2.score),2) as '平均成绩'
from tb_student t1 join tb_score t2 on t1.stuid = t2.stuid
group by t1.sname
order by round(avg(t2.score),2) desc;