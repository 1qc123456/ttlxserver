SELECT  c.name AS 班级名称, t.name AS 班主任姓名   from  t_tea_class tc
JOIN t_teacher t ON tc.t_id = t.id AND tc.ishead = '是'
JOIN t_class c  ON c.id = tc.c_id