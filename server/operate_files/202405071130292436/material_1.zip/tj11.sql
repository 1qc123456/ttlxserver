SELECT c.name AS 班级名称, COUNT(s.id) AS 学生数量  
FROM t_class c  
LEFT JOIN t_student s ON c.id = s.c_id  
GROUP BY c.id, c.name;