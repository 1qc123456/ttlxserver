TYPE=VIEW
query=select `c`.`name` AS `班级名称`,`s`.`name` AS `学生姓名`,`s`.`sex` AS `性别`,`s`.`age` AS `年龄`,`t`.`name` AS `班主任姓名` from (((`db_school`.`t_student` `s` join `db_school`.`t_class` `c` on((`s`.`c_id` = `c`.`id`))) join `db_school`.`t_tea_class` `tc` on(((`c`.`id` = `tc`.`c_id`) and (`tc`.`ishead` = \'是\')))) join `db_school`.`t_teacher` `t` on((`tc`.`t_id` = `t`.`id`)))
md5=a094203dd1435330875843c7e9df0eb8
updatable=1
algorithm=0
definer_user=root
definer_host=localhost
suid=2
with_check_option=0
timestamp=2024-05-07 03:22:27
create-version=1
source=SELECT   \n    c.name AS 班级名称,  \n    s.name AS 学生姓名,  \n    s.sex AS 性别,  \n    s.age AS 年龄,  \n    t.name AS 班主任姓名  \nFROM t_student s  \nJOIN t_class c ON s.c_id = c.id  \nJOIN t_tea_class tc ON c.id = tc.c_id AND tc.ishead = \'是\' \nJOIN t_teacher t ON tc.t_id = t.id
client_cs_name=utf8mb4
connection_cl_name=utf8mb4_general_ci
view_body_utf8=select `c`.`name` AS `班级名称`,`s`.`name` AS `学生姓名`,`s`.`sex` AS `性别`,`s`.`age` AS `年龄`,`t`.`name` AS `班主任姓名` from (((`db_school`.`t_student` `s` join `db_school`.`t_class` `c` on((`s`.`c_id` = `c`.`id`))) join `db_school`.`t_tea_class` `tc` on(((`c`.`id` = `tc`.`c_id`) and (`tc`.`ishead` = \'是\')))) join `db_school`.`t_teacher` `t` on((`tc`.`t_id` = `t`.`id`)))
