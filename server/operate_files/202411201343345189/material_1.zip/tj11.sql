select sum(price)
from tb_commodity
where cname like '%电视机' and birth >= '2022-01-01';