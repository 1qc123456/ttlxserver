select * from tb_commodity
where cname like '%小米%'
order by price desc;