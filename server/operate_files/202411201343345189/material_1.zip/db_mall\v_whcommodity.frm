TYPE=VIEW
query=select `db_mall`.`tb_commodity`.`cno` AS `cno`,`db_mall`.`tb_commodity`.`cname` AS `cname`,`db_mall`.`tb_commodity`.`ctype` AS `ctype`,`db_mall`.`tb_commodity`.`origin` AS `origin`,`db_mall`.`tb_commodity`.`birth` AS `birth`,`db_mall`.`tb_commodity`.`price` AS `price` from `db_mall`.`tb_commodity` where (`db_mall`.`tb_commodity`.`origin` = \'武汉\') order by `db_mall`.`tb_commodity`.`price`
md5=80a819a83d79ac2a47a9852293df8d1d
updatable=1
algorithm=0
definer_user=root
definer_host=localhost
suid=2
with_check_option=0
timestamp=2024-11-20 09:02:44
create-version=1
source=select * from tb_commodity\nwhere origin = \'武汉\'\norder by price
client_cs_name=utf8mb4
connection_cl_name=utf8mb4_general_ci
view_body_utf8=select `db_mall`.`tb_commodity`.`cno` AS `cno`,`db_mall`.`tb_commodity`.`cname` AS `cname`,`db_mall`.`tb_commodity`.`ctype` AS `ctype`,`db_mall`.`tb_commodity`.`origin` AS `origin`,`db_mall`.`tb_commodity`.`birth` AS `birth`,`db_mall`.`tb_commodity`.`price` AS `price` from `db_mall`.`tb_commodity` where (`db_mall`.`tb_commodity`.`origin` = \'武汉\') order by `db_mall`.`tb_commodity`.`price`
