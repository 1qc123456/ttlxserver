TYPE=VIEW
query=select `t3`.`sname` AS `sname`,count(0) AS `count(*)` from ((`db_club`.`t_group` `t1` join `db_club`.`t_gs` `t2` on((`t1`.`gno` = `t2`.`gno`))) join `db_club`.`t_student` `t3` on((`t2`.`sno` = `t3`.`sno`))) group by `t3`.`sname` having (count(0) > 1) order by count(0) desc
md5=41d09014f184f66056fd9417885af20b
updatable=0
algorithm=0
definer_user=root
definer_host=localhost
suid=2
with_check_option=0
timestamp=2024-11-01 02:31:51
create-version=1
source=select t3.sname,count(*)\nfrom t_group t1 join t_gs t2 on t1.gno=t2.gno\njoin t_student t3 on t2.sno=t3.sno\ngroup by t3.sname\nhaving count(*) >1\norder by count(*) desc
client_cs_name=utf8mb4
connection_cl_name=utf8mb4_general_ci
view_body_utf8=select `t3`.`sname` AS `sname`,count(0) AS `count(*)` from ((`db_club`.`t_group` `t1` join `db_club`.`t_gs` `t2` on((`t1`.`gno` = `t2`.`gno`))) join `db_club`.`t_student` `t3` on((`t2`.`sno` = `t3`.`sno`))) group by `t3`.`sname` having (count(0) > 1) order by count(0) desc
