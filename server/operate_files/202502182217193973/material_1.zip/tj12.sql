select t1.gname as '社团名称',t2.joindate as '参加社团时间',t2.role as '职务'
from t_group t1 join t_gs t2 on t1.gno=t2.gno
join t_student t3 on t2.sno=t3.sno
where t3.sname="孙元";