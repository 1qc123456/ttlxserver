select t3.sname as '学生姓名',t3.sex as '性别',t3.birthday as '出生日期',t3.native as '籍贯'
from t_group t1 join t_gs t2 on t1.gno=t2.gno
join t_student t3 on t2.sno=t3.sno
where t1.gname = '武术社';