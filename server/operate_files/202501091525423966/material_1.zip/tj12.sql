SELECT t_video.id as '编号', t_video.title as '标题', t_video.link as '链接地址'
FROM t_video  
JOIN t_course ON t_video.c_id = t_course.id  
WHERE t_course.name = '语文';