TYPE=VIEW
query=select `s`.`name` AS `学生姓名`,`c`.`name` AS `课程名称`,`l`.`schedule` AS `学习进度`,`l`.`createtime` AS `创建时间` from ((`db_education`.`t_student` `s` join `db_education`.`t_learn` `l` on((`s`.`id` = `l`.`s_id`))) join `db_education`.`t_course` `c` on((`l`.`c_id` = `c`.`id`)))
md5=52c78a5d4292d19e465bffbac6cfad1d
updatable=1
algorithm=0
definer_user=root
definer_host=localhost
suid=1
with_check_option=0
timestamp=2025-02-19 06:44:14
create-version=1
source=select `s`.`name` AS `学生姓名`,`c`.`name` AS `课程名称`,`l`.`schedule` AS `学习进度`,`l`.`createtime` AS `创建时间` from ((`t_student` `s` join `t_learn` `l` on((`s`.`id` = `l`.`s_id`))) join `t_course` `c` on((`l`.`c_id` = `c`.`id`)))
client_cs_name=utf8mb4
connection_cl_name=utf8mb4_general_ci
view_body_utf8=select `s`.`name` AS `学生姓名`,`c`.`name` AS `课程名称`,`l`.`schedule` AS `学习进度`,`l`.`createtime` AS `创建时间` from ((`db_education`.`t_student` `s` join `db_education`.`t_learn` `l` on((`s`.`id` = `l`.`s_id`))) join `db_education`.`t_course` `c` on((`l`.`c_id` = `c`.`id`)))
