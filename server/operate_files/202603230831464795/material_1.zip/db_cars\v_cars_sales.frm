TYPE=VIEW
query=select `c`.`cname` AS `汽车名称`,sum((`s`.`sale_quantity` * `s`.`sale_price`)) AS `累计销售金额` from (`db_cars`.`tb_sales_records` `s` join `db_cars`.`tb_cars` `c` on((`c`.`cid` = `s`.`cid`))) where (`s`.`sale_date` between \'2024-01-01\' and \'2024-12-31\') group by `c`.`cid`,`c`.`cname` order by `累计销售金额` desc limit 3
md5=cc20c3538ec42f133a71b54a2e5e18b0
updatable=0
algorithm=0
definer_user=root
definer_host=localhost
suid=2
with_check_option=0
timestamp=2025-11-17 09:00:47
create-version=1
source=SELECT\n    c.cname AS 汽车名称,\n    SUM(s.sale_quantity * s.sale_price) AS 累计销售金额\nFROM tb_sales_records s\nJOIN tb_cars c ON c.cid = s.cid\nWHERE s.sale_date BETWEEN \'2024-01-01\' AND \'2024-12-31\'\nGROUP BY c.cid, c.cname\nORDER BY 累计销售金额 DESC\nLIMIT 3
client_cs_name=utf8mb4
connection_cl_name=utf8mb4_general_ci
view_body_utf8=select `c`.`cname` AS `汽车名称`,sum((`s`.`sale_quantity` * `s`.`sale_price`)) AS `累计销售金额` from (`db_cars`.`tb_sales_records` `s` join `db_cars`.`tb_cars` `c` on((`c`.`cid` = `s`.`cid`))) where (`s`.`sale_date` between \'2024-01-01\' and \'2024-12-31\') group by `c`.`cid`,`c`.`cname` order by `累计销售金额` desc limit 3
