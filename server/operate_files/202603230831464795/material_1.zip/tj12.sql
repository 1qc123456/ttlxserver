SELECT g.gname                    AS 等级名称,
       SUM(sr.sale_quantity)      AS 总销量,
       SUM(sr.sale_quantity * sr.sale_price) AS 总销售额
FROM tb_sales_records AS sr
JOIN tb_cars          AS c  ON sr.cid = c.cid
JOIN tb_grade         AS g  ON c.gid  = g.gid
WHERE sr.sale_date BETWEEN '2024-01-01' AND '2024-12-31'
GROUP BY g.gid, g.gname
HAVING 总销售额 >= 1000000.00
ORDER BY 总销售额 DESC;