SELECT ci.cid,
       c.cname,
       ci.inventory_quantity
FROM tb_car_inventory AS ci
JOIN tb_cars AS c ON ci.cid = c.cid
WHERE ci.inbound_date >= '2024-01-01'
  AND ci.inventory_quantity > 10
ORDER BY ci.inventory_quantity DESC;