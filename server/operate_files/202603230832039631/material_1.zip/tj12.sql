select t1.name as '商品名称',t1.num + ifnull(sum(t2.quantity),0) as '进货总量'
from tb_goods t1 left join tb_orders t2 on t1.id = t2.gid
group by t1.name,t1.id
order by t1.num + ifnull(sum(t2.quantity),0) desc;