select t1.name as '商品名称',sum(t2.quantity) as '购买总数量'
from tb_goods t1 join tb_orders t2 on t1.id = t2.gid
group by t1.name;