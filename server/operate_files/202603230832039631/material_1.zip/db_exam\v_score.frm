TYPE=VIEW
query=select `t1`.`sname` AS `学生姓名`,sum(`t2`.`score`) AS `总成绩` from (`db_exam`.`tb_student` `t1` join `db_exam`.`tb_score` `t2` on((`t1`.`stuid` = `t2`.`stuid`))) group by `t1`.`sname` having (sum(`t2`.`score`) > 200) order by sum(`t2`.`score`) limit 5
md5=cba32ea82a23dbc27ae8dbe19331bad0
updatable=0
algorithm=0
definer_user=root
definer_host=localhost
suid=1
with_check_option=0
timestamp=2025-12-05 03:05:54
create-version=1
source=select `t1`.`sname` AS `学生姓名`,sum(`t2`.`score`) AS `总成绩` from (`tb_student` `t1` join `tb_score` `t2` on((`t1`.`stuid` = `t2`.`stuid`))) group by `t1`.`sname` having (sum(`t2`.`score`) > 200) order by sum(`t2`.`score`) limit 5
client_cs_name=utf8mb4
connection_cl_name=utf8mb4_general_ci
view_body_utf8=select `t1`.`sname` AS `学生姓名`,sum(`t2`.`score`) AS `总成绩` from (`db_exam`.`tb_student` `t1` join `db_exam`.`tb_score` `t2` on((`t1`.`stuid` = `t2`.`stuid`))) group by `t1`.`sname` having (sum(`t2`.`score`) > 200) order by sum(`t2`.`score`) limit 5
