select sum(t1.days) as '天数',sum(t1.rooms * t1.days * t2.rprice) as '总价'
from tb_booking t1 join tb_room t2 on t1.rno = t2.rno
where t2.rtype = '电竞房';