TYPE=VIEW
query=select `t2`.`cname` AS `客户姓名`,sum(`t1`.`days`) AS `天数` from (`db_booking`.`tb_booking` `t1` join `db_booking`.`tb_customers` `t2` on((`t1`.`cno` = `t2`.`cno`))) group by `t2`.`cname` having (count(0) > 2) order by sum(`t1`.`days`) desc limit 3
md5=315d93dacecc503f377d3bdf399ba613
updatable=0
algorithm=0
definer_user=root
definer_host=localhost
suid=2
with_check_option=0
timestamp=2024-11-08 06:55:18
create-version=1
source=select t2.cname as \'客户姓名\',sum(t1.days) as \'天数\'\nfrom tb_booking t1 join tb_customers t2 on t1.cno = t2.cno\ngroup by cname\nhaving count(*) > 2\norder by sum(t1.days) desc\nlimit 3
client_cs_name=utf8mb4
connection_cl_name=utf8mb4_general_ci
view_body_utf8=select `t2`.`cname` AS `客户姓名`,sum(`t1`.`days`) AS `天数` from (`db_booking`.`tb_booking` `t1` join `db_booking`.`tb_customers` `t2` on((`t1`.`cno` = `t2`.`cno`))) group by `t2`.`cname` having (count(0) > 2) order by sum(`t1`.`days`) desc limit 3
