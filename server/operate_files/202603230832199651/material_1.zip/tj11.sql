select t2.cname as '姓名',t2.telNo as '电话'
from tb_booking t1 join tb_customers t2 on t1.cno = t2.cno
where t1.days = 5;