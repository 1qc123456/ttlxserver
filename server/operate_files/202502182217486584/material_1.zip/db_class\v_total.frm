TYPE=VIEW
query=select `t1`.`name` AS `学生姓名`,sum(`t2`.`score`) AS `总分` from (`db_class`.`t_student` `t1` join `db_class`.`t_score` `t2` on((`t1`.`id` = `t2`.`stuid`))) group by `t1`.`name` order by sum(`t2`.`score`) desc limit 10
md5=023d9306c2a264ec2d7db7f0c0d44da4
updatable=0
algorithm=0
definer_user=root
definer_host=localhost
suid=2
with_check_option=0
timestamp=2025-02-12 03:35:53
create-version=1
source=select t1.name as \'学生姓名\',sum(t2.score) as \'总分\'\nfrom t_student t1 join t_score t2 on t1.id = t2.stuid\ngroup by t1.name\norder by sum(t2.score) desc\nlimit 10
client_cs_name=utf8mb4
connection_cl_name=utf8mb4_general_ci
view_body_utf8=select `t1`.`name` AS `学生姓名`,sum(`t2`.`score`) AS `总分` from (`db_class`.`t_student` `t1` join `db_class`.`t_score` `t2` on((`t1`.`id` = `t2`.`stuid`))) group by `t1`.`name` order by sum(`t2`.`score`) desc limit 10
