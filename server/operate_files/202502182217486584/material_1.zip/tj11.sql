select c.name as '班级名称',count(distinct s.stuid) as '人数'
from t_class c join t_score s on c.id = s.claid
group by c.name;