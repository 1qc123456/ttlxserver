select sum(case when sex = '男' then 1 else 0 end) as '男生人数',sum(case when sex = '女' then 1 else 0 end) as '女生人数',avg(age) as '平均年龄'
from t_student;