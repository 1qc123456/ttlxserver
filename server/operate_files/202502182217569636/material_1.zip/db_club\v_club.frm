TYPE=VIEW
query=select `t1`.`gname` AS `社团名称`,count(`t2`.`gno`) AS `参加人数` from (`db_club`.`t_group` `t1` join `db_club`.`t_gs` `t2` on((`t1`.`gno` = `t2`.`gno`))) where (`t2`.`gno` = \'g101\') group by `t1`.`gname`
md5=5908e9252a90c9e5cbe4247e313e4cdf
updatable=0
algorithm=0
definer_user=root
definer_host=localhost
suid=1
with_check_option=0
timestamp=2025-02-18 03:19:23
create-version=1
source=select `t1`.`gname` AS `社团名称`,count(`t2`.`gno`) AS `参加人数` from (`t_group` `t1` join `t_gs` `t2` on((`t1`.`gno` = `t2`.`gno`))) where (`t2`.`gno` = \'g101\') group by `t1`.`gname`
client_cs_name=utf8mb4
connection_cl_name=utf8mb4_general_ci
view_body_utf8=select `t1`.`gname` AS `社团名称`,count(`t2`.`gno`) AS `参加人数` from (`db_club`.`t_group` `t1` join `db_club`.`t_gs` `t2` on((`t1`.`gno` = `t2`.`gno`))) where (`t2`.`gno` = \'g101\') group by `t1`.`gname`
