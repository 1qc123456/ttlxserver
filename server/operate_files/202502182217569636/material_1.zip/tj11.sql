select t3.sno as '学号',t3.sname as '姓名',t2.joindate as '时间',t2.role as '职务'
from t_group t1 join t_gs t2 on t1.gno = t2.gno
join t_student t3 on t2.sno = t3.sno
where t1.gname = '话剧社';