select sum(remainder) as '总名额',floor(avg(remainder)) as '平均名额',max(remainder) as '最多名额',min(remainder) as '最少名额'
from t_group;