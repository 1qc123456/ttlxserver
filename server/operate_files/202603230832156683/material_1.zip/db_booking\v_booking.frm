TYPE=VIEW
query=select `t2`.`cname` AS `客户姓名`,`t3`.`rtype` AS `客房类型`,`t1`.`rooms` AS `预订数量`,`t1`.`days` AS `预计入住天数` from ((`db_booking`.`tb_customers` `t2` join `db_booking`.`tb_booking` `t1` on((`t2`.`cno` = `t1`.`cno`))) join `db_booking`.`tb_room` `t3` on((`t1`.`rno` = `t3`.`rno`))) where ((`t1`.`rooms` >= 3) and (`t1`.`days` > 3)) order by `t1`.`days` desc
md5=fbdc2b7072b7be36b1022e2ebd1791e2
updatable=1
algorithm=0
definer_user=root
definer_host=localhost
suid=1
with_check_option=0
timestamp=2025-12-04 02:50:19
create-version=1
source=select `t2`.`cname` AS `客户姓名`,`t3`.`rtype` AS `客房类型`,`t1`.`rooms` AS `预订数量`,`t1`.`days` AS `预计入住天数` from ((`tb_customers` `t2` join `tb_booking` `t1` on((`t2`.`cno` = `t1`.`cno`))) join `tb_room` `t3` on((`t1`.`rno` = `t3`.`rno`))) where ((`t1`.`rooms` >= 3) and (`t1`.`days` > 3)) order by `t1`.`days` desc
client_cs_name=utf8mb4
connection_cl_name=utf8mb4_general_ci
view_body_utf8=select `t2`.`cname` AS `客户姓名`,`t3`.`rtype` AS `客房类型`,`t1`.`rooms` AS `预订数量`,`t1`.`days` AS `预计入住天数` from ((`db_booking`.`tb_customers` `t2` join `db_booking`.`tb_booking` `t1` on((`t2`.`cno` = `t1`.`cno`))) join `db_booking`.`tb_room` `t3` on((`t1`.`rno` = `t3`.`rno`))) where ((`t1`.`rooms` >= 3) and (`t1`.`days` > 3)) order by `t1`.`days` desc
