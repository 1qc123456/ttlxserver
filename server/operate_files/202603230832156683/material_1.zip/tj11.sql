select t2.cname as '姓名',count(*) as '预订单总数'
from tb_booking t1 join tb_customers t2 on t1.cno = t2.cno
where t2.telNo like '177%'
group by t2.cname;