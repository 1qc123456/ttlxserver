select t1.bno as '预订单号',t2.cname as '客户姓名',t3.rtype as '客房类型',t1.bdate as '预订日期'
from tb_customers t2 join tb_booking t1 on t2.cno = t1.cno
join tb_room t3 on t1.rno = t3.rno
where t1.bdate > '2024-10-25'
order by t1.bdate
limit 3;