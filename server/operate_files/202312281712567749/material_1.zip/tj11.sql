select cname,integral,CASE
	WHEN integral < 1000 THEN '普通会员'
	WHEN integral < 3000 THEN '中级会员'
	WHEN integral < 5000 THEN '高级会员'
	ELSE '顶级会员' END as 会员等级
 from t_client;