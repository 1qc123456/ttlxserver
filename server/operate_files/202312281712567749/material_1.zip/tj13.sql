SELECT t1.cid,t3.cname,SUM(price) as totalSpend FROM t_booking t1 LEFT JOIN t_room t2 on t1.rid = t2.rid
LEFT JOIN t_client t3 on t1.cid = t3.cid
GROUP BY t1.cid,t3.cname
HAVING SUM(price) = (
SELECT MAX(totalSpend) FROM (
SELECT cid,SUM(price) as totalSpend FROM t_booking t1 LEFT JOIN t_room t2 on t1.rid = t2.rid
GROUP BY cid) as subquery);