SELECT t1.hname,ROUND(AVG(price),2) avgprice FROM t_hotel t1 JOIN t_room t2 on t1.hid = t2.hid 
GROUP BY t1.hname
ORDER BY avgprice DESC;