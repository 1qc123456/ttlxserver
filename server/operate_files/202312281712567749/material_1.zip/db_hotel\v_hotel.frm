TYPE=VIEW
query=select date_format(`t1`.`btime`,\'%Y-%m\') AS `bmonth`,sum(`t2`.`price`) AS `totalPrice` from (`db_hotel`.`t_booking` `t1` left join `db_hotel`.`t_room` `t2` on((`t1`.`rid` = `t2`.`rid`))) group by date_format(`t1`.`btime`,\'%Y-%m\') order by `bmonth`
md5=058281567c5663776a17c8b3e95bce1f
updatable=0
algorithm=0
definer_user=root
definer_host=localhost
suid=2
with_check_option=0
timestamp=2023-12-26 02:51:54
create-version=1
source=select DATE_FORMAT(btime, \'%Y-%m\') as bmonth,SUM(t2.price) totalPrice from t_booking t1  \nLEFT JOIN t_room t2 on t1.rid = t2.rid  \nGROUP BY  DATE_FORMAT(btime, \'%Y-%m\')  \norder by bmonth
client_cs_name=utf8mb4
connection_cl_name=utf8mb4_general_ci
view_body_utf8=select date_format(`t1`.`btime`,\'%Y-%m\') AS `bmonth`,sum(`t2`.`price`) AS `totalPrice` from (`db_hotel`.`t_booking` `t1` left join `db_hotel`.`t_room` `t2` on((`t1`.`rid` = `t2`.`rid`))) group by date_format(`t1`.`btime`,\'%Y-%m\') order by `bmonth`
