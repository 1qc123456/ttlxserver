var init=0;
if(jQuery("#menuOnIndex").val()!=undefined){
	init=jQuery("#menuOnIndex").val();
}
jQuery(".nav").slide( {
	type : "menu", //效果类型
	titCell : ".m", // 鼠标触发对象
	targetCell : ".sub", // 效果对象，必须被titCell包含
	delayTime : 300, // 效果时间
	triggerTime : 0, //鼠标延迟触发时间
	defaultIndex:init,
	returnDefault : true //返回默认状态
});
$(function(){
	jQuery("#searchTxt").focus(function(){if(this.value=='请输入搜索的关键字'){this.value='';this.style.color='#000';}});
	jQuery("#searchTxt").blur(function(){if(this.value==''){this.style.color='#c8c8c8';this.value='请输入搜索的关键字';}});
});