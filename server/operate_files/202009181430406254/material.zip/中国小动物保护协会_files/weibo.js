WB2.anyWhere(function(W) {
	W.widget.followButton( {
		'nick_name' : '中国-小动物保护协会', //用户昵称
		'id' : "wb_follow_btn",
		'show_head' : true, //是否显示头像
		'show_name' : true, //是否显示名称
		'show_cancel' : true //是否显示取消关注按钮
	});
});