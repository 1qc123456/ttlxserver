SELECT   
    s.type AS 场地类别,  
    ROUND(AVG(l.duration),2) AS 平均租借时长  
FROM   
    t_lease l  
JOIN   
    t_site s ON l.sid = s.sid  
GROUP BY   
    s.type  
HAVING   
    AVG(l.duration) > 3;