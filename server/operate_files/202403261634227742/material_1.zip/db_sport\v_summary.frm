TYPE=VIEW
query=select `c`.`name` AS `客户姓名`,`c`.`integral` AS `总积分`,sum((`l`.`duration` * `s`.`price`)) AS `租借总花费` from ((`db_sport`.`t_client` `c` join `db_sport`.`t_lease` `l` on((`c`.`cid` = `l`.`cid`))) join `db_sport`.`t_site` `s` on((`l`.`sid` = `s`.`sid`))) group by `c`.`cid`,`c`.`name`,`c`.`integral`
md5=e781efb9ec609842349ac6ee7e3df5d2
updatable=0
algorithm=0
definer_user=root
definer_host=localhost
suid=2
with_check_option=0
timestamp=2024-03-26 08:17:11
create-version=1
source=SELECT   \n    c.name AS 客户姓名,  \n    c.integral AS 总积分,  \n    SUM(l.duration * s.price) AS 租借总花费  \nFROM   \n    t_client c  \nJOIN   \n    t_lease l ON c.cid = l.cid  \nJOIN   \n    t_site s ON l.sid = s.sid  \nGROUP BY   \n    c.cid, c.name, c.integral
client_cs_name=utf8mb4
connection_cl_name=utf8mb4_general_ci
view_body_utf8=select `c`.`name` AS `客户姓名`,`c`.`integral` AS `总积分`,sum((`l`.`duration` * `s`.`price`)) AS `租借总花费` from ((`db_sport`.`t_client` `c` join `db_sport`.`t_lease` `l` on((`c`.`cid` = `l`.`cid`))) join `db_sport`.`t_site` `s` on((`l`.`sid` = `s`.`sid`))) group by `c`.`cid`,`c`.`name`,`c`.`integral`
