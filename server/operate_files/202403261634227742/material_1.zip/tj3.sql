SELECT   
    c.cid AS 客户编号,  
    c.name AS 客户姓名,  
    c.integral AS 总积分,  
    SUM(l.duration) AS 租借总时长  
FROM   
    t_client c  
LEFT JOIN   
    t_lease l ON c.cid = l.cid  
GROUP BY   
    c.cid, c.name, c.integral;