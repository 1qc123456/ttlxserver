select b.name,a.duration from t_lease a
join t_site b on a.sid=b.sid
where MONTH(a.time)=5 order by a.duration DESC
LIMIT 4