select t2.stuname,t2.gender,t2.birthday,t3.cname,t1.score,
CASE 
WHEN t1.score < 60 THEN '不及格'
WHEN t1.score >= 60 && t1.score < 70 THEN '及格'
WHEN t1.score >= 70 && t1.score < 80 THEN '中等'
WHEN t1.score >= 80 && t1.score < 90 THEN '良好'
WHEN t1.score > 90 THEN '优秀'
ELSE ''
END as 等级
	from tb_scores t1 
	LEFT JOIN tb_students t2 on t1.student_id = t2.stuid 
	LEFT JOIN tb_courses t3 on t1.course_id = t3.cid order by score desc