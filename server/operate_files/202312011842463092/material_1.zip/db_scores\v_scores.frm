TYPE=VIEW
query=select `t2`.`cname` AS `cname`,ceiling(avg(`t1`.`score`)) AS `CEILING(AVG(t1.score))`,max(`t1`.`score`) AS `MAX(t1.score)`,min(`t1`.`score`) AS `MIN(t1.score)` from (`db_scores`.`tb_scores` `t1` left join `db_scores`.`tb_courses` `t2` on((`t1`.`course_id` = `t2`.`cid`))) group by `t2`.`cname` order by avg(`t1`.`score`) desc
md5=f069eaefc5a28713d12fefc07e55e454
updatable=0
algorithm=0
definer_user=root
definer_host=localhost
suid=2
with_check_option=0
timestamp=2023-12-01 10:38:19
create-version=1
source=select t2.cname,CEILING(AVG(t1.score)),MAX(t1.score),MIN(t1.score) from tb_scores t1 LEFT JOIN tb_courses t2 on t1.course_id = t2.cid\n	group by t2.cname\n	ORDER BY AVG(t1.score)  DESC
client_cs_name=utf8mb4
connection_cl_name=utf8mb4_general_ci
view_body_utf8=select `t2`.`cname` AS `cname`,ceiling(avg(`t1`.`score`)) AS `CEILING(AVG(t1.score))`,max(`t1`.`score`) AS `MAX(t1.score)`,min(`t1`.`score`) AS `MIN(t1.score)` from (`db_scores`.`tb_scores` `t1` left join `db_scores`.`tb_courses` `t2` on((`t1`.`course_id` = `t2`.`cid`))) group by `t2`.`cname` order by avg(`t1`.`score`) desc
