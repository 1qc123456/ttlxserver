select t1.dname as '部门名称',
sum(case when t2.sex = '男' then 1 else 0 end) as '男生人数',
sum(case when t2.sex = '女' then 1 else 0 end) as '女生人数'
from t_department t1 join t_salary t3 on t1.did = t3.did
join t_employee t2 on t3.eid = t2.eid
group by t1.dname;