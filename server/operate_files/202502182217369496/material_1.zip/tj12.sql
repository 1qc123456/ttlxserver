select t1.dname as '部门名称',max(t3.element_salary)
from t_department t1 join t_salary t3 on t1.did = t3.did
join t_employee t2 on t3.eid = t2.eid
group by t1.dname
order by max(t3.element_salary) desc;