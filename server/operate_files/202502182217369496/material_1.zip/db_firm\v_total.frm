TYPE=VIEW
query=select `t2`.`ename` AS `员工姓名`,`t2`.`position` AS `职位`,(`t3`.`element_salary` + `t3`.`extra_salary`) AS `总薪资` from ((`db_firm`.`t_department` `t1` join `db_firm`.`t_salary` `t3` on((`t1`.`did` = `t3`.`did`))) join `db_firm`.`t_employee` `t2` on((`t3`.`eid` = `t2`.`eid`))) where ((`t3`.`element_salary` + `t3`.`extra_salary`) > 6000) order by (`t3`.`element_salary` + `t3`.`extra_salary`) desc
md5=b6dfc1dbedab6d094cd396c9504957d3
updatable=1
algorithm=0
definer_user=root
definer_host=localhost
suid=1
with_check_option=0
timestamp=2025-02-18 01:50:04
create-version=1
source=select t2.ename as \'员工姓名\',t2.position as \'职位\',t3.element_salary + t3.extra_salary as \'总薪资\'\nfrom t_department t1 join t_salary t3 on t1.did = t3.did\njoin t_employee t2 on t3.eid = t2.eid\nwhere t3.element_salary + t3.extra_salary > 6000\norder by t3.element_salary + t3.extra_salary desc
client_cs_name=utf8mb4
connection_cl_name=utf8mb4_general_ci
view_body_utf8=select `t2`.`ename` AS `员工姓名`,`t2`.`position` AS `职位`,(`t3`.`element_salary` + `t3`.`extra_salary`) AS `总薪资` from ((`db_firm`.`t_department` `t1` join `db_firm`.`t_salary` `t3` on((`t1`.`did` = `t3`.`did`))) join `db_firm`.`t_employee` `t2` on((`t3`.`eid` = `t2`.`eid`))) where ((`t3`.`element_salary` + `t3`.`extra_salary`) > 6000) order by (`t3`.`element_salary` + `t3`.`extra_salary`) desc
