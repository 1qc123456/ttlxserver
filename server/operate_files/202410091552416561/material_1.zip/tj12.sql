select e.ename as '职工姓名',s.basepay as '基本工资'
from t_employee e join t_salary s on e.eno = s.eno
join t_department d on e.dno = d.dno
where d.dname = '行政部'
order by basepay desc;