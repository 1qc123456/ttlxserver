select ename,birthday from t_employee
where year(birthday) = 1985
order by birthday;