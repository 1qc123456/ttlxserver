TYPE=VIEW
query=select `d`.`dname` AS `dname`,count(`e`.`eno`) AS `empcount` from (`db_salary`.`t_department` `d` join `db_salary`.`t_employee` `e` on((`d`.`dno` = `e`.`dno`))) group by `d`.`dname`
md5=1b81a5b62bb1747e7c6167755795f3a2
updatable=0
algorithm=0
definer_user=root
definer_host=localhost
suid=2
with_check_option=0
timestamp=2024-10-09 07:49:01
create-version=1
source=select d.dname,count(e.eno) as empcount\nfrom t_department d join t_employee e on d.dno = e.dno\ngroup by d.dname
client_cs_name=utf8mb4
connection_cl_name=utf8mb4_general_ci
view_body_utf8=select `d`.`dname` AS `dname`,count(`e`.`eno`) AS `empcount` from (`db_salary`.`t_department` `d` join `db_salary`.`t_employee` `e` on((`d`.`dno` = `e`.`dno`))) group by `d`.`dname`
