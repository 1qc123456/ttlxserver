TYPE=VIEW
query=select `t1`.`order_id` AS `order_id`,`t1`.`customer_name` AS `customer_name`,count(0) AS `count(*)`,sum((`t2`.`quantity` * `t2`.`price`)) AS `SUM(t2.quantity * t2.price)` from (`db_orders`.`tb_order` `t1` join `db_orders`.`tb_order_detail` `t2` on((`t1`.`order_id` = `t2`.`order_id`))) group by `t1`.`order_id`,`t1`.`customer_name`
md5=a6f59beff519dd445c9006fdddd992b5
updatable=0
algorithm=0
definer_user=root
definer_host=localhost
suid=2
with_check_option=0
timestamp=2023-11-21 06:42:57
create-version=1
source=select t1.order_id,t1.customer_name,count(*),SUM(t2.quantity * t2.price) from tb_order t1 \n	INNER JOIN  tb_order_detail t2 ON t1.order_id = t2.order_id \n	GROUP BY t1.order_id,t1.customer_name
client_cs_name=utf8mb4
connection_cl_name=utf8mb4_general_ci
view_body_utf8=select `t1`.`order_id` AS `order_id`,`t1`.`customer_name` AS `customer_name`,count(0) AS `count(*)`,sum((`t2`.`quantity` * `t2`.`price`)) AS `SUM(t2.quantity * t2.price)` from (`db_orders`.`tb_order` `t1` join `db_orders`.`tb_order_detail` `t2` on((`t1`.`order_id` = `t2`.`order_id`))) group by `t1`.`order_id`,`t1`.`customer_name`
