SELECT 
    rc.comment_content AS 评论内容,
    n.novel_title AS 小说标题,
    a.pen_name AS 作者笔名
FROM 
    reader_comments rc
JOIN novels n ON rc.novel_id = n.novel_id
JOIN authors a ON n.author_id = a.author_id
WHERE 
    rc.reader_age = (SELECT MAX(reader_age) FROM reader_comments);