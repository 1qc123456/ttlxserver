SELECT 
    a.pen_name AS '作者笔名',
    a.fan_count AS '作者粉丝数',
    COUNT(n.novel_id) AS '小说总数',
    ROUND(AVG(n.score), 2) AS '平均评分',
    MAX(n.score) AS '最高评分',
    MIN(n.score) AS '最低评分'
FROM authors a
INNER JOIN novels n ON a.author_id = n.author_id
GROUP BY a.author_id, a.pen_name, a.fan_count
HAVING COUNT(n.novel_id) > 1
ORDER BY a.fan_count DESC;