SELECT e_id 员工编号, AVG(money) AS 平均工资  
FROM t_salary
GROUP BY e_id
ORDER BY AVG(money) DESC
LIMIT 10;