TYPE=VIEW
query=select `s`.`name` AS `学生姓名`,`s`.`sex` AS `性别`,`s`.`grade` AS `年级`,`s`.`major` AS `专业`,`co`.`name` AS `课程名称` from ((`db_course`.`t_student` `s` join `db_course`.`t_choice` `ch` on((`s`.`id` = `ch`.`sid`))) join `db_course`.`t_course` `co` on((`ch`.`cid` = `co`.`id`)))
md5=fa374b5e740513e9cbacbea257105627
updatable=1
algorithm=0
definer_user=root
definer_host=localhost
suid=2
with_check_option=0
timestamp=2025-05-27 02:20:10
create-version=1
source=SELECT \n    s.name AS 学生姓名,\n    s.sex AS 性别,\n    s.grade AS 年级,\n    s.major AS 专业,\n    co.name AS 课程名称\nFROM t_student s\nJOIN t_choice ch ON s.id = ch.sid\nJOIN t_course co ON ch.cid = co.id
client_cs_name=utf8mb4
connection_cl_name=utf8mb4_general_ci
view_body_utf8=select `s`.`name` AS `学生姓名`,`s`.`sex` AS `性别`,`s`.`grade` AS `年级`,`s`.`major` AS `专业`,`co`.`name` AS `课程名称` from ((`db_course`.`t_student` `s` join `db_course`.`t_choice` `ch` on((`s`.`id` = `ch`.`sid`))) join `db_course`.`t_course` `co` on((`ch`.`cid` = `co`.`id`)))
