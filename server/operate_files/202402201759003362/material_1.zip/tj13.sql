SELECT s.id AS 学生编号, s.name AS 姓名, s.grade AS 年级
FROM t_student s
JOIN t_choice c ON s.id = c.sid
JOIN t_course co ON c.cid = co.id
WHERE co.name = '网页设计';