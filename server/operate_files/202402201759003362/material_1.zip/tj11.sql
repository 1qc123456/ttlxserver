SELECT *
FROM t_student
WHERE major = '软件工程' AND grade = '大一';