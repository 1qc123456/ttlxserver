SELECT s.name AS 姓名, COUNT(c.id) AS 选课个数
FROM t_student s
LEFT JOIN t_choice c ON s.id = c.sid
GROUP BY s.id
HAVING COUNT(c.id) < 3;