/**
 * Created by Administrator on 2018/2/4.
 */
$(function () {
    var allHeader = $('.headerbox-wrap');
    var sub_nav = allHeader.find('.navbox-subnav-wrap');
    var subNav_content = sub_nav.find('.navbox-subnav-content');
    var nav_item = allHeader.find('[data-subnav]');
    var timer = null;

    nav_item.hover(function () {
        clearTimeout(timer);

        hoverChange();

        var getVal = $(this).attr('data-subnav');
        var subNav_cur = $('.navbox-subnav-content[data-link='+getVal+']');
        var cur_imgs = subNav_cur.find('a');
        goodsShow(subNav_cur);
        showImg(cur_imgs);
    }, function () {
        timer = setTimeout(function () {
            outChange();
        }, 100);
    });

    sub_nav.hover(function () {
        clearTimeout(timer);
    }, function () {
        timer = setTimeout(function () {
            outChange();
        }, 100);
    });

    // 当前容器显示
    function goodsShow(subNav_cur) {
        subNav_content.hide();
        subNav_cur.show();
    }

    // 小列表显示
    function showImg(aImg) {
        var num = 0;
        var timer = null;

        aImg.css({opacity: 0, marginLeft: 30});

        for (var i = 0; i < aImg.length; i++) {
            aImg.eq(i).animate({marginLeft: 0, opacity: 1}, 500);

            if (i === aImg.length - 1) {
                clearInterval(timer);
            }
        }
    }



    function hoverChange() {
        sub_nav.stop().animate({height: 100},{queue:false,duration: 200, easing: 'easeOutExpo',});
    }

    function outChange() {
        subNav_content.hide();
        sub_nav.stop().animate({height: 0},{queue:false,duration: 200, easing: 'easeInExpo',});
    }

    //顶部banner
    if($.cookie('topbanner') != 1){
        $('#top-banner').stop().delay(1500).show().animate({paddingTop:'31.04%'},100);
        var timers = setTimeout(function () {
            $('#top-banner').stop().animate({paddingTop:'0%'},100);
        },8000);
        var h=new Date();
        h.setTime(h.getTime()+(30*60*1000));
        $.cookie("topbanner","1",{expires:h});

    }
    //document.cookie
    $('.topbanner-closebtn').on('click',function () {
        clearTimeout(timers);
        $('#top-banner').stop().animate({paddingTop:'0%'},100);
        var h=new Date();
        h.setTime(h.getTime()+(30*60*1000));
        $.cookie("topbanner","1",{expires:h});
    });

    //新闻综合页面侧栏效果
    var $li = $('.newsall-side-list ul li');
    $('.newsall-side-list ul li:eq(0) a').find('img').show();
    $('.newsall-side-list ul li:eq(0) a').find('p').show();
    $('.newsall-side-list ul li:eq(0) a').find('h3').addClass('curs');
    $li.hover(function (index) {
       var i = $li.index(this);
        $('.newsall-side-list ul li:eq('+i+') a').find('img').show()
            .parents().siblings('li').find('a').find('img').hide();
        $('.newsall-side-list ul li:eq('+i+') a').find('p').show()
            .parents().siblings('li').find('a').find('p').hide();
        $('.newsall-side-list ul li:eq('+i+') a').find('h3').addClass('curs')
            .parents().siblings('li').find('a').find('h3').removeClass('curs');
    });

    //登录
    $('.navbox-user').hover(function () {
        $(this).find('.navbox-user-infos').show();
    },function () {
        $(this).find('.navbox-user-infos').hide();
    });

    //美景tab
    var mjbtn = $('.playzjj-mj-tabmenu a');
    var tab_mj_infos = $('.playzjj-mj-tabbox .playzjj-mj-tabcontent');
    tab_mj_infos.eq(0).show();
    mjbtn.eq(0).addClass('curs');
    mjbtn.mouseover(function (index) {
        $(this).addClass('curs').siblings(this).removeClass('curs');
        var tabIndex_mj = mjbtn.index(this);
        tab_mj_infos.eq(tabIndex_mj).show().siblings(tab_mj_infos).hide();
    });
    //住宿tab
    var zsbtn = $('.pz-alllist-htab a');
    var tab_zs_infos = $('.pz-alllist-htabcontent .pz-alllist-htabbox');
    tab_zs_infos.eq(0).show();
    zsbtn.eq(0).addClass('curs');
    zsbtn.mouseover(function (index) {
        $(this).addClass('curs').siblings(this).removeClass('curs');
        var tabIndex_zs = zsbtn.index(this);
        tab_zs_infos.eq(tabIndex_zs).show().siblings(tab_zs_infos).hide();
    });

    //交通tab
    var jtbtn = $('.pz-jt-tabbtn a');
    var tab_jt_infos = $('.pz-jt-tab-infobox .pz-jt-tab-content');
    tab_jt_infos.eq(0).show();
    jtbtn.eq(0).addClass('curs');
    jtbtn.mouseover(function (index) {
        $(this).addClass('curs').siblings(this).removeClass('curs');
        var tabIndex_jt = jtbtn.index(this);
        tab_jt_infos.eq(tabIndex_jt).show().siblings(tab_jt_infos).hide();
    });
    //交通内容下的tab
    var fjtbtn = $('.pz-jt-ftabbox a');
    var tab_fjt_infos = $('.pz-jt-ftabboxs .pz-jt-ftabinfos');
    tab_fjt_infos.eq(0).show();
    fjtbtn.eq(0).addClass('fcurs');
    fjtbtn.mouseover(function (index) {
        $(this).addClass('fcurs').siblings(this).removeClass('fcurs');
        var tabIndex_fjt = fjtbtn.index(this);
        tab_fjt_infos.eq(tabIndex_fjt).show().siblings(tab_fjt_infos).hide();
    });

    var msbtn = $('.pz-alllist-mstabbtn a');
    var tab_ms_infos = $('.pz-alllist-mstabinfos .pz-alllist-mstabbox');
    tab_ms_infos.eq(0).show();
    msbtn.eq(0).addClass('curs');
    msbtn.mouseover(function (index) {
        $(this).addClass('curs').siblings(this).removeClass('curs');
        var tabIndex_ms = msbtn.index(this);
        tab_ms_infos.eq(tabIndex_ms).show().siblings(tab_ms_infos).hide();
    });
})