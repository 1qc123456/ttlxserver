$(function () {
    $('#focusimg').responsiveSlides({
        pager: true,
        nav: false,
        speed:1000,
        timeout:5000,
        namespace: 'centered-btns',
    });


    $('#h-hotfocus').responsiveSlides({
        auto:false,
        manualControls: '#h-slider-pager'
    });


    /**
     * 自动计算幻灯片按钮位置
     */
    function focusNavBtnPos() {
        var _w = $('.centered-btns_tabs').width();
        console.log(_w);
        var _bw = $(window).width();
        console.log(_bw);
        var _nw = (parseInt(_bw)/2) - (parseInt(_w)/2);
        console.log(_nw);
        $('.centered-btns_tabs').css({marginLeft:_nw+"px"});
    }
    focusNavBtnPos();
    $(window).on('resize', function() {
        focusNavBtnPos();
    })
    //玩转张家界tab选项卡
    var obj = $('.h-playzjj-tabnav li');
    var tab_contents = $('.h-playzjj-tabinfo .h-playzjj-tablist');
    tab_contents.eq(0).show();
    obj.eq(0).addClass('curs');
    obj.mouseover(function (index) {
        $(this).addClass('curs').siblings(this).removeClass('curs');
        var tabIndex = obj.index(this);
        tab_contents.eq(tabIndex).show().siblings(tab_contents).hide();
    });
})