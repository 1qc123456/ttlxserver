TYPE=VIEW
query=select `db_orders`.`tb_products`.`product_id` AS `product_id`,`db_orders`.`tb_products`.`name` AS `name`,`db_orders`.`tb_products`.`price` AS `price`,`db_orders`.`tb_products`.`stock` AS `stock` from `db_orders`.`tb_products` where (`db_orders`.`tb_products`.`price` > (select avg(`db_orders`.`tb_products`.`price`) from `db_orders`.`tb_products` where (`db_orders`.`tb_products`.`stock` > 100))) order by `db_orders`.`tb_products`.`price` desc
md5=78c05f728042bac138cda5a5a47aff18
updatable=0
algorithm=0
definer_user=root
definer_host=localhost
suid=2
with_check_option=0
timestamp=2025-11-11 03:39:48
create-version=1
source=SELECT product_id,\nname,\nprice,\nstock\nFROM   tb_products\nWHERE  price > (\nSELECT AVG(price)\nFROM   tb_products\nWHERE  stock > 100\n)\nORDER  BY price DESC
client_cs_name=utf8mb4
connection_cl_name=utf8mb4_general_ci
view_body_utf8=select `db_orders`.`tb_products`.`product_id` AS `product_id`,`db_orders`.`tb_products`.`name` AS `name`,`db_orders`.`tb_products`.`price` AS `price`,`db_orders`.`tb_products`.`stock` AS `stock` from `db_orders`.`tb_products` where (`db_orders`.`tb_products`.`price` > (select avg(`db_orders`.`tb_products`.`price`) from `db_orders`.`tb_products` where (`db_orders`.`tb_products`.`stock` > 100))) order by `db_orders`.`tb_products`.`price` desc
