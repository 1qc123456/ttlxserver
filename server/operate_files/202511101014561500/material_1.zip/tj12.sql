SELECT 
    c.name AS customer_name,
    c.email,
    SUM(o.total_amount) AS total_spent
FROM tb_customers c
INNER JOIN tb_orders o ON c.customer_id = o.customer_id
WHERE o.order_date BETWEEN '2025-06-01'  and '2025-06-30'
GROUP BY c.customer_id, c.name, c.email
HAVING total_spent > 20000
ORDER BY total_spent DESC;