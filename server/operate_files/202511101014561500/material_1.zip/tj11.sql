SELECT
o.order_id,
c.name AS customer_name,
o.order_date,
o.total_amount
FROM tb_orders AS o
JOIN tb_customers AS c ON o.customer_id = c.customer_id
WHERE o.status = '已支付'
AND o.order_date BETWEEN '2025-01-01' AND '2025-06-30'
ORDER BY o.order_date DESC;