TYPE=VIEW
query=select `t1`.`cname` AS `cname`,sum((case when (`t2`.`sex` = \'男\') then 1 else 0 end)) AS `男生数量`,sum((case when (`t2`.`sex` = \'女\') then 1 else 0 end)) AS `女生数量`,count(0) AS `总人数` from (`db_school`.`t_class` `t1` left join `db_school`.`t_student` `t2` on((`t1`.`cid` = `t2`.`cid`))) group by `t1`.`cname`
md5=e19e0966c2303f2ac513f2ef851082ea
updatable=0
algorithm=0
definer_user=root
definer_host=localhost
suid=2
with_check_option=0
timestamp=2024-01-20 09:39:00
create-version=1
source=select t1.cname,\nSUM(CASE WHEN t2.sex  = \'男\' THEN 1 ELSE 0 END) 男生数量,\nSUM(CASE WHEN t2.sex  = \'女\' THEN 1 ELSE 0 END) 女生数量,\nCOUNT(*) 总人数 from t_class t1  LEFT JOIN t_student t2 on t1.cid = t2.cid GROUP BY t1.cname
client_cs_name=utf8mb4
connection_cl_name=utf8mb4_general_ci
view_body_utf8=select `t1`.`cname` AS `cname`,sum((case when (`t2`.`sex` = \'男\') then 1 else 0 end)) AS `男生数量`,sum((case when (`t2`.`sex` = \'女\') then 1 else 0 end)) AS `女生数量`,count(0) AS `总人数` from (`db_school`.`t_class` `t1` left join `db_school`.`t_student` `t2` on((`t1`.`cid` = `t2`.`cid`))) group by `t1`.`cname`
