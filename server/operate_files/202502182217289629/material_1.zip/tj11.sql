select sum(age) as '年龄总和',avg(age) as '平均年龄',max(age) as '最大年龄',min(age) as '最小年龄'
from t_student;