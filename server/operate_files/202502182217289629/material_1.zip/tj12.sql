select t3.name as '学科名称',t2.name as '学生姓名',t1.score as '成绩'
from t_student t2 join t_score t1 on t2.id = t1.stuid
join t_subject t3 on t1.subid = t3.id
where t3.name = '数学'
order by t1.score desc
limit 5;