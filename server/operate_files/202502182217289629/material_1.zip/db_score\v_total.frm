TYPE=VIEW
query=select `t2`.`name` AS `学生姓名`,sum(`t1`.`score`) AS `总成绩` from (`db_score`.`t_score` `t1` join `db_score`.`t_student` `t2` on((`t1`.`stuid` = `t2`.`id`))) group by `t2`.`name` order by sum(`t1`.`score`) desc
md5=2980a67fd6e75310393e219455878e6c
updatable=0
algorithm=0
definer_user=root
definer_host=localhost
suid=2
with_check_option=0
timestamp=2024-10-21 08:02:09
create-version=1
source=select t2.name as \'学生姓名\',sum(t1.score) as \'总成绩\'\nfrom t_score t1 join t_student t2 on t1.stuid = t2.id\ngroup by t2.name\norder by sum(t1.score) desc
client_cs_name=utf8mb4
connection_cl_name=utf8mb4_general_ci
view_body_utf8=select `t2`.`name` AS `学生姓名`,sum(`t1`.`score`) AS `总成绩` from (`db_score`.`t_score` `t1` join `db_score`.`t_student` `t2` on((`t1`.`stuid` = `t2`.`id`))) group by `t2`.`name` order by sum(`t1`.`score`) desc
