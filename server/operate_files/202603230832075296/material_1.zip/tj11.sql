select cname as '课程名',max(score) as '最高分',min(score) as '最低分'
from tb_score
group by cname;