select cname as '课程名',ceil(avg(score)) as '平均分'
from tb_score
group by cname;