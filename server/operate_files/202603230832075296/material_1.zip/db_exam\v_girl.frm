TYPE=VIEW
query=select `t2`.`sname` AS `学生姓名`,`t2`.`sex` AS `性别`,sum(`t1`.`score`) AS `总成绩` from (`db_exam`.`tb_score` `t1` join `db_exam`.`tb_student` `t2` on((`t1`.`stuid` = `t2`.`stuid`))) where (`t2`.`sex` = \'女\') group by `t2`.`sname` order by sum(`t1`.`score`) desc limit 3
md5=d8d07f7a1ee9b542b87d08f673268cf9
updatable=0
algorithm=0
definer_user=root
definer_host=localhost
suid=1
with_check_option=0
timestamp=2025-12-05 01:41:56
create-version=1
source=select `t2`.`sname` AS `学生姓名`,`t2`.`sex` AS `性别`,sum(`t1`.`score`) AS `总成绩` from (`tb_score` `t1` join `tb_student` `t2` on((`t1`.`stuid` = `t2`.`stuid`))) where (`t2`.`sex` = \'女\') group by `t2`.`sname` order by sum(`t1`.`score`) desc limit 3
client_cs_name=utf8mb4
connection_cl_name=utf8mb4_general_ci
view_body_utf8=select `t2`.`sname` AS `学生姓名`,`t2`.`sex` AS `性别`,sum(`t1`.`score`) AS `总成绩` from (`db_exam`.`tb_score` `t1` join `db_exam`.`tb_student` `t2` on((`t1`.`stuid` = `t2`.`stuid`))) where (`t2`.`sex` = \'女\') group by `t2`.`sname` order by sum(`t1`.`score`) desc limit 3
