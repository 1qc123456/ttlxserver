TYPE=VIEW
query=select `s`.`name` AS `学生姓名`,`c`.`name` AS `班级名称`,`co`.`name` AS `科目名称`,`g`.`score` AS `分数` from (((`db_grade`.`t_student` `s` join `db_grade`.`t_class` `c` on((`s`.`cla_id` = `c`.`id`))) join `db_grade`.`t_grade` `g` on((`s`.`id` = `g`.`stu_id`))) join `db_grade`.`t_course` `co` on((`g`.`cou_id` = `co`.`id`))) order by `c`.`name`
md5=8383970457c9b4fff37644b0703c71c2
updatable=1
algorithm=0
definer_user=root
definer_host=localhost
suid=1
with_check_option=0
timestamp=2025-03-20 01:24:00
create-version=1
source=select `s`.`name` AS `学生姓名`,`c`.`name` AS `班级名称`,`co`.`name` AS `科目名称`,`g`.`score` AS `分数` from (((`t_student` `s` join `t_class` `c` on((`s`.`cla_id` = `c`.`id`))) join `t_grade` `g` on((`s`.`id` = `g`.`stu_id`))) join `t_course` `co` on((`g`.`cou_id` = `co`.`id`))) order by `c`.`name`
client_cs_name=utf8mb4
connection_cl_name=utf8mb4_general_ci
view_body_utf8=select `s`.`name` AS `学生姓名`,`c`.`name` AS `班级名称`,`co`.`name` AS `科目名称`,`g`.`score` AS `分数` from (((`db_grade`.`t_student` `s` join `db_grade`.`t_class` `c` on((`s`.`cla_id` = `c`.`id`))) join `db_grade`.`t_grade` `g` on((`s`.`id` = `g`.`stu_id`))) join `db_grade`.`t_course` `co` on((`g`.`cou_id` = `co`.`id`))) order by `c`.`name`
