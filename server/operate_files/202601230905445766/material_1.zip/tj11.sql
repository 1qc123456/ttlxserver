SELECT c.name AS 科目名称, MAX(g.score) AS 最高分, MIN(g.score) AS 最低分  
FROM t_grade g  
JOIN t_course c ON g.cou_id = c.id  
GROUP BY c.name;