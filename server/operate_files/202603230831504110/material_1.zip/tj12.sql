SELECT 
    DATE_FORMAT(sale_date, '%Y-%m') AS sale_month,
    COUNT(*) AS sales_count
FROM 
    tb_sales_records
WHERE 
    MONTH(sale_date) = 12
GROUP BY 
    DATE_FORMAT(sale_date, '%Y-%m');