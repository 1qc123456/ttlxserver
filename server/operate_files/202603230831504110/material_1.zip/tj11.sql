SELECT 
    sr.sid,
    c.cname,
    sr.sale_date,
    sr.sale_quantity,
    sr.sale_price
FROM 
    tb_sales_records sr
JOIN 
    tb_cars c ON sr.cid = c.cid
WHERE 
    sr.sale_price >= 200000;