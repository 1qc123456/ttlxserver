TYPE=VIEW
query=select `c`.`cname` AS `cname`,sum(`sr`.`sale_quantity`) AS `total_sales`,sum((`sr`.`sale_quantity` * `sr`.`sale_price`)) AS `total_sales_amount`,avg(`sr`.`sale_price`) AS `average_sale_price` from (`db_cars`.`tb_sales_records` `sr` join `db_cars`.`tb_cars` `c` on((`sr`.`cid` = `c`.`cid`))) group by `c`.`cname`
md5=c3b982f543624690465c704ab66e3620
updatable=0
algorithm=0
definer_user=root
definer_host=localhost
suid=2
with_check_option=0
timestamp=2025-07-03 05:40:20
create-version=1
source=SELECT \n    c.cname,\n    SUM(sr.sale_quantity) AS total_sales,\n    SUM(sr.sale_quantity * sr.sale_price) AS total_sales_amount,\n    AVG(sr.sale_price) AS average_sale_price\nFROM \n    tb_sales_records sr\nJOIN \n    tb_cars c ON sr.cid = c.cid\nGROUP BY \n    c.cname
client_cs_name=utf8mb4
connection_cl_name=utf8mb4_general_ci
view_body_utf8=select `c`.`cname` AS `cname`,sum(`sr`.`sale_quantity`) AS `total_sales`,sum((`sr`.`sale_quantity` * `sr`.`sale_price`)) AS `total_sales_amount`,avg(`sr`.`sale_price`) AS `average_sale_price` from (`db_cars`.`tb_sales_records` `sr` join `db_cars`.`tb_cars` `c` on((`sr`.`cid` = `c`.`cid`))) group by `c`.`cname`
