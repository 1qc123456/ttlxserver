TYPE=VIEW
query=select `t1`.`gname` AS `社团名称`,`t3`.`class` AS `班级`,count(0) AS `成员总数` from ((`db_society`.`tb_group` `t1` join `db_society`.`tb_gs` `t2` on((`t1`.`gno` = `t2`.`gno`))) join `db_society`.`tb_student` `t3` on((`t2`.`sno` = `t3`.`sno`))) where (`t1`.`gname` = \'篮球社\') group by `t3`.`class`
md5=d6bf3c9356974200a1951c93f6dd91cc
updatable=0
algorithm=0
definer_user=root
definer_host=localhost
suid=2
with_check_option=0
timestamp=2024-11-07 08:49:32
create-version=1
source=select t1.gname as \'社团名称\',t3.class as \'班级\',count(*) as \'成员总数\'\nfrom tb_group t1 join tb_gs t2 on t1.gno = t2.gno\njoin tb_student t3 on t2.sno = t3.sno\nwhere t1.gname = \'篮球社\'\ngroup by t3.class
client_cs_name=utf8mb4
connection_cl_name=utf8mb4_general_ci
view_body_utf8=select `t1`.`gname` AS `社团名称`,`t3`.`class` AS `班级`,count(0) AS `成员总数` from ((`db_society`.`tb_group` `t1` join `db_society`.`tb_gs` `t2` on((`t1`.`gno` = `t2`.`gno`))) join `db_society`.`tb_student` `t3` on((`t2`.`sno` = `t3`.`sno`))) where (`t1`.`gname` = \'篮球社\') group by `t3`.`class`
