select nation as '民族',sname as '学生姓名',sex as '性别'
from tb_student
where nation != '汉族'
order by nation;