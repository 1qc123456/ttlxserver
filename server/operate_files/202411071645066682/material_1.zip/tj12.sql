select gname as '社团名称',sname as '学生姓名',grole as '承担的工作'
from tb_group t1 join tb_gs t2 on t1.gno = t2.gno
join tb_student t3 on t2.sno = t3.sno
where t2.grole='社长';