SELECT id, name, DATE_FORMAT(time,'%Y年%c月%e日')    
FROM t_class;