SELECT a.name AS 教练姓名, b.name AS 班级名称, b.period AS 课时  
FROM t_coach a   
JOIN t_class b ON a.id= b.coachId  
WHERE a.name like '何%';