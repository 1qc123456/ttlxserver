SELECT *   
FROM t_coach   
ORDER BY salary ASC   
LIMIT 2 OFFSET 1;