TYPE=VIEW
query=select `s`.`name` AS `学员姓名`,`c`.`name` AS `教练姓名`,`b`.`name` AS `班级名称` from ((`db_swim`.`t_student` `s` join `db_swim`.`t_class` `b` on((`s`.`classId` = `b`.`id`))) join `db_swim`.`t_coach` `c` on((`b`.`coachId` = `c`.`id`)))
md5=881690af7e6b5d55a94aa656c06c9f39
updatable=1
algorithm=0
definer_user=root
definer_host=localhost
suid=2
with_check_option=0
timestamp=2024-01-31 11:39:10
create-version=1
source=SELECT s.name AS 学员姓名, c.name AS 教练姓名, b.name AS 班级名称   \nFROM t_student s   \nJOIN t_class b ON s.classId = b.id   \nJOIN t_coach c ON b.coachId = c.id
client_cs_name=utf8mb4
connection_cl_name=utf8mb4_general_ci
view_body_utf8=select `s`.`name` AS `学员姓名`,`c`.`name` AS `教练姓名`,`b`.`name` AS `班级名称` from ((`db_swim`.`t_student` `s` join `db_swim`.`t_class` `b` on((`s`.`classId` = `b`.`id`))) join `db_swim`.`t_coach` `c` on((`b`.`coachId` = `c`.`id`)))
