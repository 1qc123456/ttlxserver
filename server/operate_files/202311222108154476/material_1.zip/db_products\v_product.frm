TYPE=VIEW
query=select `t1`.`category_name` AS `category_name`,count(0) AS `COUNT(*)`,min(`t2`.`price`) AS `MIN(t2.price)` from (`db_products`.`tb_category` `t1` left join `db_products`.`tb_product` `t2` on((`t1`.`category_id` = `t2`.`category_id`))) where (`t1`.`category_name` <> \'厨具\') group by `t1`.`category_name`
md5=6f8615ed7bf18ac06552a9bab6ef230f
updatable=0
algorithm=0
definer_user=root
definer_host=localhost
suid=2
with_check_option=0
timestamp=2023-11-22 12:41:33
create-version=1
source=select t1.category_name,COUNT(*),MIN(t2.price) from tb_category t1 \n	LEFT JOIN tb_product t2 on t1.category_id = t2.category_id  \n	where t1.category_name != \'厨具\' GROUP BY t1.category_name
client_cs_name=utf8mb4
connection_cl_name=utf8mb4_general_ci
view_body_utf8=select `t1`.`category_name` AS `category_name`,count(0) AS `COUNT(*)`,min(`t2`.`price`) AS `MIN(t2.price)` from (`db_products`.`tb_category` `t1` left join `db_products`.`tb_product` `t2` on((`t1`.`category_id` = `t2`.`category_id`))) where (`t1`.`category_name` <> \'厨具\') group by `t1`.`category_name`
