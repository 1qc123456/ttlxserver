TYPE=VIEW
query=select `db_sports`.`t_athletes`.`name` AS `运动员姓名`,`db_sports`.`t_sport`.`name` AS `参赛项目`,`db_sports`.`t_match`.`grade` AS `成绩` from ((`db_sports`.`t_athletes` join `db_sports`.`t_match` on((`db_sports`.`t_athletes`.`id` = `db_sports`.`t_match`.`aid`))) join `db_sports`.`t_sport` on((`db_sports`.`t_sport`.`id` = `db_sports`.`t_match`.`sid`)))
md5=396c50073eea463b7f6a76cb50367522
updatable=1
algorithm=0
definer_user=root
definer_host=localhost
suid=2
with_check_option=0
timestamp=2024-02-01 06:19:01
create-version=1
source=SELECT\n	t_athletes.NAME AS 运动员姓名,\n	t_sport.NAME AS 参赛项目,\n	t_match.grade AS 成绩 \nFROM\n	t_athletes\n	JOIN t_match ON t_athletes.id = t_match.aid\n	JOIN t_sport ON t_sport.id = t_match.sid
client_cs_name=utf8mb4
connection_cl_name=utf8mb4_general_ci
view_body_utf8=select `db_sports`.`t_athletes`.`name` AS `运动员姓名`,`db_sports`.`t_sport`.`name` AS `参赛项目`,`db_sports`.`t_match`.`grade` AS `成绩` from ((`db_sports`.`t_athletes` join `db_sports`.`t_match` on((`db_sports`.`t_athletes`.`id` = `db_sports`.`t_match`.`aid`))) join `db_sports`.`t_sport` on((`db_sports`.`t_sport`.`id` = `db_sports`.`t_match`.`sid`)))
