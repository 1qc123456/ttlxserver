SELECT
	t_sport.`name`,
	t_athletes.`name`, t_athletes.sex,t_athletes.birthday
FROM
	t_athletes
	JOIN t_match ON t_athletes.id = t_match.aid
	JOIN t_sport ON t_sport.id = t_match.sid 
WHERE
	t_match.grade = '第一名';