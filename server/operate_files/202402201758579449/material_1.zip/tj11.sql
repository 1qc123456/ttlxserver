SELECT sex, COUNT(*) AS number
FROM t_athletes
GROUP BY sex;