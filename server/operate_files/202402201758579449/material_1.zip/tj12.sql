SELECT 
    name AS name,
    TIMESTAMPDIFF(YEAR, birthday, '2024-01-01') AS age
FROM t_athletes;