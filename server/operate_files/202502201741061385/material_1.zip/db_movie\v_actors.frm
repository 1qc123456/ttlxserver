TYPE=VIEW
query=select `a`.`aname` AS `演员姓名`,`a`.`birth` AS `出生年份` from (`db_movie`.`t_actors` `a` join `db_movie`.`t_characters` `c` on((`a`.`cid` = `c`.`cid`))) where ((char_length(`c`.`cname`) >= 3) and (`a`.`birth` is not null))
md5=e8eb35afef1d06cd6c8642e1b5b2b536
updatable=1
algorithm=0
definer_user=root
definer_host=localhost
suid=2
with_check_option=0
timestamp=2025-02-21 01:05:08
create-version=1
source=SELECT a.aname AS 演员姓名, a.birth AS 出生年份\nFROM t_actors a\nJOIN t_characters c ON a.cid = c.cid\nWHERE CHAR_LENGTH(c.cname) >= 3 AND a.birth IS NOT NULL
client_cs_name=utf8mb4
connection_cl_name=utf8mb4_general_ci
view_body_utf8=select `a`.`aname` AS `演员姓名`,`a`.`birth` AS `出生年份` from (`db_movie`.`t_actors` `a` join `db_movie`.`t_characters` `c` on((`a`.`cid` = `c`.`cid`))) where ((char_length(`c`.`cname`) >= 3) and (`a`.`birth` is not null))
