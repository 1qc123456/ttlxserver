select t4.mid as '电影编号',t2.cname as '角色名称',t3.line as '台词内容'
from t_movies t4 join t_characters t2 on t4.mid = t2.mid
join t_line t3 on t2.cid = t3.cid
where t4.mname = '哪吒之魔童闹海';