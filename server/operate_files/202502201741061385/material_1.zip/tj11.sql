select t1.aname as '演员姓名',t2.cname as '角色名称'
from t_actors t1 join t_characters t2 on t1.cid = t2.cid
where t2.cname like '%哪吒%';