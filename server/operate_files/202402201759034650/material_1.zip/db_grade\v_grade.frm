TYPE=VIEW
query=select `s`.`sname` AS `sname`,`s`.`class` AS `class`,`c`.`cname` AS `cname`,`g`.`score` AS `score` from ((`db_grade`.`t_student` `s` join `db_grade`.`t_grade` `g` on((`s`.`sid` = `g`.`sid`))) join `db_grade`.`t_course` `c` on((`g`.`cid` = `c`.`cid`)))
md5=966e619a3ae060aac33f9640662f580c
updatable=1
algorithm=0
definer_user=root
definer_host=localhost
suid=2
with_check_option=0
timestamp=2024-02-01 02:47:25
create-version=1
source=SELECT\n	s.sname,\n	class,\n	c.cname,\n	g.score \nFROM\n	t_student s\n	JOIN t_grade g ON s.sid = g.sid\n	JOIN t_course c ON g.cid = c.cid
client_cs_name=utf8mb4
connection_cl_name=utf8mb4_general_ci
view_body_utf8=select `s`.`sname` AS `sname`,`s`.`class` AS `class`,`c`.`cname` AS `cname`,`g`.`score` AS `score` from ((`db_grade`.`t_student` `s` join `db_grade`.`t_grade` `g` on((`s`.`sid` = `g`.`sid`))) join `db_grade`.`t_course` `c` on((`g`.`cid` = `c`.`cid`)))
