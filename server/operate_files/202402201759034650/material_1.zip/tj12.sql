SELECT
	class,
	ROUND( AVG( score ), 2 ) AS avg_score 
FROM
	t_grade t1
	JOIN t_student t2 ON t1.sid = t2.sid 
GROUP BY
	class 
ORDER BY
	avg_score DESC;