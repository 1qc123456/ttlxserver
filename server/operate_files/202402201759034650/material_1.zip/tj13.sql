SELECT
	cname,
	MAX( score ) AS max_score,
	MIN( score ) AS min_score 
FROM
	t_grade t1
	JOIN t_course t2 ON t1.cid = t2.cid 
GROUP BY
	cname;