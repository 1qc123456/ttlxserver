SELECT
	sname,
	total_score 
FROM
	t_student
	JOIN ( SELECT sid, SUM( score ) AS total_score FROM t_grade GROUP BY sid ORDER BY total_score DESC LIMIT 5 ) AS g ON g.sid = t_student.sid