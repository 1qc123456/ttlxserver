SELECT name AS 会员姓名,  
    CASE   
        WHEN integral < 1000 THEN '普通会员'  
        WHEN integral < 3000 THEN '白银会员'  
        WHEN integral < 5000 THEN '黄金会员'  
        ELSE '黑金会员'  
    END AS mgrade
FROM t_member;