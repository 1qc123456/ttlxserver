SELECT t.name AS 私教姓名, SUM(c.price) AS total_price  
FROM t_trainer t  
JOIN t_course c ON t.id = c.t_id  
WHERE t.name = '许秀英';