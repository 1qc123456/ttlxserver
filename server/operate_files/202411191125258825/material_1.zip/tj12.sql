select t1.sname as '姓名',t2.score as '成绩'
from tb_student t1 join tb_order t2 on t1.sno = t2.sno
where t2.score < 60;