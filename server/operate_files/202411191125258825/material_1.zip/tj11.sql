select sname as '姓名',age as '年龄'
from tb_student where sex = '男'
order by age;