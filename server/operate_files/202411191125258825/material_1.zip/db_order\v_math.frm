TYPE=VIEW
query=select `t1`.`sname` AS `学生姓名`,`t2`.`score` AS `成绩` from ((`db_order`.`tb_student` `t1` join `db_order`.`tb_order` `t2` on((`t1`.`sno` = `t2`.`sno`))) join `db_order`.`tb_course` `t3` on((`t2`.`cno` = `t3`.`cno`))) where (`t3`.`cname` = \'高等数学\') order by `t2`.`score` desc limit 5
md5=4d38b8590b8dbce7985ef1deca863834
updatable=0
algorithm=0
definer_user=root
definer_host=localhost
suid=2
with_check_option=0
timestamp=2024-11-19 03:24:51
create-version=1
source=select t1.sname as \'学生姓名\',t2.score as \'成绩\'\nfrom tb_student t1 join tb_order t2 on t1.sno = t2.sno\njoin tb_course t3 on t2.cno = t3.cno\nwhere t3.cname = \'高等数学\'\norder by score desc\nlimit 5
client_cs_name=utf8mb4
connection_cl_name=utf8mb4_general_ci
view_body_utf8=select `t1`.`sname` AS `学生姓名`,`t2`.`score` AS `成绩` from ((`db_order`.`tb_student` `t1` join `db_order`.`tb_order` `t2` on((`t1`.`sno` = `t2`.`sno`))) join `db_order`.`tb_course` `t3` on((`t2`.`cno` = `t3`.`cno`))) where (`t3`.`cname` = \'高等数学\') order by `t2`.`score` desc limit 5
