/**
 *	description:ZMAX js文件
 *				这些JS主要是完成系统必要的一些用户交互功能
 *  author：min.zhang
 *  Email:zhang19min88@163.com
 *	Url:http://www.zmax99.com
 *  copyright:南宁市程序人软件科技有限责任公司保留所有权利
 *  date:2017-07-25
 =========================================================
	ZMAX AJAX返回新规定，所有的AJAX都应该使用JSON格式。
	返回一个对象
		err属性， code=0表示正常 其他情况为异常 msg为异常信息 
				  errmsg 是已经格式化后的错误消息
		data属性  data表示正常应该返回的数据
								by min.zhang  2017-07-27
 =========================================================
 */
 
//所有的ZMAX扩展都遵循如下的代码规范
jQuery(document).ready(function(){
  
  //处理SITEBASE TOKEN变量声明失败 ：在某一些模板中，使用JFactory::getDocument()->addScriptDeclaration 可能会不起作用
  if(typeof ZMAX_SYSTEM_AJAX_SITE_BASE=="undefined")
  {
	  ZMAX_SYSTEM_AJAX_SITE_BASE="";
  }
  
  if(typeof ZMAX_SYSTEM_AJAX_TOKEN=="undefined")
  {
		ZMAX_SYSTEM_AJAX_TOKEN="";
  }
});
 
 
jQuery(document).ready(function(){
	
	//选中一个项目的时候
	jQuery(".zitemlist-container .zitem").click(function(){
		var id =  jQuery(this).data("id");
		var key =  jQuery(this).data("key");
		setData(id,key);
		jQuery(".zitemlist-container .zitem").removeClass("selected");
		jQuery(".system-no-container").html(1);
		jQuery(this).addClass("selected");
	});  
	
	//点击清空的时候
	jQuery(".system-clear-selected").click(function(){
		if(jQuery(this).hasClass("layui-disabled"))
		{
			return true;
		}
		setData(0);
	}); 
	
	//当创建分类的时候
	jQuery(document).on('click',".system-zmaxcdn-create-category",function(){
		var refresh = jQuery(this).data("refresh");
		var title = jQuery(this).data("title");
		var url = jQuery(this).data("url");
		var closeParent = jQuery(this).data("closeparent");
		var width = jQuery(this).data("width");
		var height = jQuery(this).data("height");
		
		if(!width)
		{
			width = "100%";
		}
		if(!height)
		{
			height="100%";
		}
		
		var layer = layui.layer;
		layer.open({
			type:2,
			area:[width,height],
			title:title,
			btn:['保存','关闭'],
				btn2: function(index, layero){
					//return false 开启该代码可禁止点击该按钮关闭
					layer.close(index);
					return false;
				},
				btn1: function(index, layero){
					
					
					var iframeWin = window[layero.find('iframe')[0]['name']]; //得到iframe页的窗口对象，执行iframe页的方法：iframeWin.method();
					
					try{
						if(!iframeWin.layerValidateForm())
						{
							layer.iframeAuto(index);
							return false;	
						}	
					}catch(e) //如果没有定义 layer validateForm 
					{
						alert(e.message);
					}					
					
					var myform = layer.getChildFrame('form',index);
					var childLayer = window['layui-layer-iframe'+index].layer;
					var cIndex =  childLayer.load();
					var formData = jQuery(myform).serialize();							
					var action="index.php";
					
					jQuery.ajax({
						type:'POST',
						url:ZMAX_SYSTEM_AJAX_SITE_BASE+action,
						data:formData,	
						cache:false,
						processData:false,
						dataType: "json",
						success:function(data)
						{
							childLayer.close(cIndex); //关掉loading窗口
							
							if(data.err.code!=0) //有错误发生
							{
								layer.alert(data.err.errmsg,{icon: 2});	
								return false;
							}
							else
							{
								layer.close(index);	//关掉本窗口	
								layer.msg("操作成功,系统正在重新加载数据...");	
								location.reload();
								//parent.location=data.data;
								return true;
							}
						},
						error: function(XMLHttpRequest, textStatus, errorThrown)
						{
							layer.close(cIndex);
							var errmsg = '<h3>操作失败，发生了错误</h3><strong>错误详情如下：</strong><p>XMLHttpRequest.status='+XMLHttpRequest.status+"</p>";
							errmsg=errmsg+'<p>XMLHttpRequest.readyState='+XMLHttpRequest.readyState+"</p>";
							errmsg=errmsg+'<p>textStatus='+textStatus+"</p>";
							
							layer.alert(errmsg,{icon: 2});
							return false;
						}		
					});
					return false;
				},
			content:url,
			success:function(layero,index){
				layer.iframeAuto(index); //自动调整对话框大小，但是在前台有bug，不出现滚动条
			}
		});	
	});  
	
	//当需要编辑的时候
	jQuery(document).on('click',".system-zmaxcdn-modal-form",function(){
		var refresh = jQuery(this).data("refresh");
		var title = jQuery(this).data("title");
		var url = jQuery(this).data("url");
		var closeParent = jQuery(this).data("closeparent");
		var width = jQuery(this).data("width");
		var height = jQuery(this).data("height");
		
		if(!width)
		{
			width = "100%";
		}
		if(!height)
		{
			height="100%";
		}
		
		var layer = layui.layer;
		layer.open({
			type:2,
			area:[width,height],
			title:title,
			shadeClose:true,
			btn:['保存','关闭'],
				btn2: function(index, layero){
					//return false 开启该代码可禁止点击该按钮关闭
					layer.close(index);
					return false;
				},
				btn1: function(index, layero){
					
					
					var iframeWin = window[layero.find('iframe')[0]['name']]; //得到iframe页的窗口对象，执行iframe页的方法：iframeWin.method();
					
					try{
						if(!iframeWin.layerValidateForm())
						{
							layer.iframeAuto(index);
							return false;	
						}	
					}catch(e) //如果没有定义 layer validateForm 
					{
						return false;
					}					
					
					var myform = layer.getChildFrame('form',index);
					var childLayer = window['layui-layer-iframe'+index].layer;
					var cIndex =  childLayer.load();
					var formData = jQuery(myform).serialize();							
					var action="index.php";
					
					jQuery.ajax({
						type:'POST',
						url:ZMAX_SYSTEM_AJAX_SITE_BASE+action,
						data:formData,	
						cache:false,
						processData:false,
						dataType: "json",
						success:function(data)
						{
							childLayer.close(cIndex); //关掉loading窗口
							//layer.close(index);	//关掉父窗口	
							if(data.err.code!=0) //有错误发生
							{
								layer.alert(data.err.errmsg,{icon: 2});	
								return false;
							}
							else
							{
								
								var msg=data.data;
								if(refresh)
								{
									layer.open({
										type:0,
										icon:1,
										content:msg,
										yes:function(index,layero)
										{
											if(refresh==0){
												layer.close(index);	
												return true;
											}	
											parent.location.reload(); 
											return true;
										}
									 
									});
								
								}
								else
								{
									//这里我应该调用一个函数，执行插入
									if(data.data.type=="code")
									{
										var jscode = data.data.code;
										if(window.execScript) 
										{
											// 给IE的特殊待遇
											window.execScript(jscode);
										}
										else {
											// 给其他大部分浏览器用的
											window.eval(jscode);
										}
										return true;	
									}
									else
									{
										iframeWin.location= data.data.url;
										layer.msg("操作成功!");
									}
									//layer.close(index);
								}
								return true;
							}
						},
						error: function(XMLHttpRequest, textStatus, errorThrown)
						{
							layer.close(cIndex);
							var errmsg = '<h3>操作失败，发生了错误</h3><strong>错误详情如下：</strong><p>XMLHttpRequest.status='+XMLHttpRequest.status+"</p>";
							errmsg=errmsg+'<p>XMLHttpRequest.readyState='+XMLHttpRequest.readyState+"</p>";
							errmsg=errmsg+'<p>textStatus='+textStatus+"</p>";
							
							layer.alert(errmsg,{icon: 2});
							return false;
						}		
					});
					return false;
				},
			content:url,
			success:function(layero,index){
			//	layer.iframeAuto(index); //自动调整对话框大小，但是在前台有bug，不出现滚动条
			}
		});	
	});  
	
	
	jQuery(document).on('click',".system-zmaxcdn-searchtool-clean",function(){
		jQuery("#filter_search").val("");
		jQuery("#filter_type").val("");
		jQuery("#list_fullordering").val("");
	});  
	
	//当需要删除的时候
	jQuery(document).on('click',".system-at-delete-link",function(){
		var myform = jQuery("#itemdetailform");
		myform.find('input[name="task"]').val("items.ajaxDelete");
		var formData = myform.serialize();
		layer.open({
				type:0,
				content:'你确定要删除这个资源吗？在删除记录的同时也会删除存储在服务器上的文件。如果你在其他地方使用过该资源，那么可能会造成资源无法访问。请慎重删除',
				icon:0,
				btn:['确定','取消'],
				btn1:function(index,layero){
					var action="index.php";
					jQuery.ajax({
						type:'post',
						url:ZMAX_SYSTEM_AJAX_SITE_BASE+action,
						data:formData,	
						cache:false,
						dataType: "json",
						success:function(data)
						{
							if(data.err.code!=0) //有错误发生
							{
								layer.alert(data.err.errmsg,{icon: 2});	
								return false;
							}
							else
							{
								jQuery(".zitem.selected").parent().remove();
								jQuery(".system-clear-selected").trigger("click");
								layer.msg(data.data,{time:1000});
							}
						},
						error: function(XMLHttpRequest, textStatus, errorThrown) {
							jQuery(".system-zmaximagecaptcha-changeimage").trigger("click");
							var errmsg = '<h3>操作失败，发生了错误</h3><strong>错误详情如下：</strong><p>XMLHttpRequest.status='+XMLHttpRequest.status+"</p>";
							errmsg=errmsg+'<p>XMLHttpRequest.readyState='+XMLHttpRequest.readyState+"</p>";
							errmsg=errmsg+'<p>textStatus='+textStatus+"</p>";
							
							layer.alert(errmsg,{icon: 2});
							return false;
						}			
					});
				},
				btn2:function(index,layero){
				}
		});
		
	});  
	
	
	jQuery(".system-zmaxcdn-insert-btn").click(function(){
		if(jQuery(this).hasClass("layui-disabled"))
		{
			return true;
		}
		
		var myform = jQuery("#itemdetailform");
		myform.find('input[name="task"]').val("item.ajaxUpdate");
		var formData = myform.serialize();
		
		//需要对form进行提交，保存后在处理了
		var action="index.php";
		jQuery.ajax({
			type:'post',
			url:ZMAX_SYSTEM_AJAX_SITE_BASE+action,
			data:formData,	
			cache:false,
			dataType: "json",
			success:function(data)
			{
				if(data.err.code!=0) //有错误发生
				{
					layer.alert(data.err.errmsg,{icon: 2});	
					return false;
				}
				else
				{
					var jscode = data.data;
					if(window.execScript) 
					{
						// 给IE的特殊待遇
						window.execScript(jscode);
					}
					else {
						// 给其他大部分浏览器用的
						window.eval(jscode);
					}
					return true;
				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				jQuery(".system-zmaximagecaptcha-changeimage").trigger("click");
				var errmsg = '<h3>操作失败，发生了错误</h3><strong>错误详情如下：</strong><p>XMLHttpRequest.status='+XMLHttpRequest.status+"</p>";
				errmsg=errmsg+'<p>XMLHttpRequest.readyState='+XMLHttpRequest.readyState+"</p>";
				errmsg=errmsg+'<p>textStatus='+textStatus+"</p>";
				
				layer.alert(errmsg,{icon: 2});
				return false;
			}			
		});
	});
	
	
	
	jQuery(".zmaxtip").click(function(){				
		var data = jQuery(this).attr("data");
		layer.tips(data, this);
	});
	
	
	//系统下载支持
	jQuery(".zmaxpackage").click(function(){				
		var id = jQuery(this).attr("data-id");				
		jQuery.ajax({
			type:'post',
			data:{
					id:id,
				},
			url:'index.php?option=com_zmaxcdn&task=download.download',
			cache:false,
			success:function(data)
					{					
						var data = jQuery.parseJSON(data);
						if(data.canDownload)
						{	
							window.location.href = 'index.php?option=com_zmaxcdn&task=download.getFile&id='+data.id;	
							return false;
						}
						else
						{
							layer.alert(data.info);
							return false;
						}
					},	
			error: function(XMLHttpRequest, textStatus, errorThrown) 
					{
						alert(XMLHttpRequest.status);
						alert(XMLHttpRequest.readyState);
						alert(textStatus);
					}
			});
		return false;
	});
	
	/*系统弹出框支持*/ 
	jQuery('.system-zmaxcdn-modal-simple').click(function(){
		var url = jQuery(this).attr("url");
		var title = jQuery(this).attr("title");
		var width = jQuery(this).attr("width");
		var height = jQuery(this).attr("height");
		
		url = url?url:jQuery(this).data("url");
		title = title?title:jQuery(this).data("title");
		width = width?width:jQuery(this).data("width");
		height = height?height:jQuery(this).data("height");
		title=title?title:"媒体管理";
		height=height?height:"690px";
		width=width?width:"1120px";
		var layer = layui.layer;
		layer.open({
			type:2,
			area:[width,height],
			title:title,
			btn:['关闭'],
				btn1: function(index, layero){
					//return false 开启该代码可禁止点击该按钮关闭
					
					layer.close(index);
					return false;
			    },
			maxmin:true,
			shadeClose:true,
			content:url,
			success:function(layero,index){
				layer.iframeAuto(index);
			}
			
		});		
	})
});

function setData(id,key)
{
	//STEP 1 设置当前的资源ID
	var insertBtn = jQuery(".system-zmaxcdn-insert-btn");//插入按钮
	var clearBtn = jQuery(".system-clear-selected");//清除按钮
	var zitems = jQuery(".zitem"); //所有可选文件
	var noContainer = jQuery(".system-no-container");//选中文件的数量
	if(id)
	{
		insertBtn.attr("data",id).removeClass("layui-disabled");
		clearBtn.removeClass("layui-disabled");	
		noContainer.html("1");
	}
	else
	{
		zitems.removeClass("selected");
		insertBtn.addClass("layui-disabled");
		clearBtn.addClass("layui-disabled");
		noContainer.html("0");
	}
	
	//STEP 2 获得资源的详细情况
	var action="index.php?option=com_zmaxcdn&task=item.loadItem"
	jQuery.ajax({
		type:'post',
		dataType: "json", 
		url:ZMAX_SYSTEM_AJAX_SITE_BASE+action,
		data:{
			'id':id,
			'key':key
		},	
		cache:false,
		success:function(data)
		{
			if(data.err.code!=0) //有错误发生
			{
				layer.alert(data.err.errmsg,{icon: 2});	
				return false;
			}
			else
			{
				jQuery(".zattach-container").html(data.data);
				return true;
			}
		},
		error: function(XMLHttpRequest, textStatus, errorThrown) {
			jQuery(".system-zmaximagecaptcha-changeimage").trigger("click");
			var errmsg = '<h3>操作失败，发生了错误</h3><strong>错误详情如下：</strong><p>XMLHttpRequest.status='+XMLHttpRequest.status+"</p>";
			errmsg=errmsg+'<p>XMLHttpRequest.readyState='+XMLHttpRequest.readyState+"</p>";
			errmsg=errmsg+'<p>textStatus='+textStatus+"</p>";
			
			layer.alert(errmsg,{icon: 2});
			return false;
		}	
		
	});
}



