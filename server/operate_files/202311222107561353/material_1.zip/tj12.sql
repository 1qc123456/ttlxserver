select t2.class_name,t1.student_name,t1.gender from tb_student t1 LEFT JOIN tb_class t2 
	on t1.class_id = t2.class_id
	LEFT JOIN tb_teacher t3 on t2.teacher_id = t3.teacher_id
	where t3.teacher_name = '张老师';