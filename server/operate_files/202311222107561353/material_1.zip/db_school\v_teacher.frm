TYPE=VIEW
query=select `t3`.`teacher_name` AS `teacher_name`,`t2`.`class_name` AS `class_name`,count(0) AS `COUNT(*)` from ((`db_school`.`tb_student` `t1` left join `db_school`.`tb_class` `t2` on((`t1`.`class_id` = `t2`.`class_id`))) left join `db_school`.`tb_teacher` `t3` on((`t2`.`teacher_id` = `t3`.`teacher_id`))) group by `t3`.`teacher_name`,`t2`.`class_name` having (count(0) > 5)
md5=e4c198b2f415b2797d46c694d475c643
updatable=0
algorithm=0
definer_user=root
definer_host=localhost
suid=2
with_check_option=0
timestamp=2023-11-20 10:18:56
create-version=1
source=select t3.teacher_name,t2.class_name,COUNT(*) from tb_student t1 LEFT JOIN tb_class t2 on t1.class_id = t2.class_id\n	LEFT JOIN tb_teacher t3 on t2.teacher_id = t3.teacher_id group by t3.teacher_name,t2.class_name\n	HAVING COUNT(*) > 5
client_cs_name=utf8mb4
connection_cl_name=utf8mb4_general_ci
view_body_utf8=select `t3`.`teacher_name` AS `teacher_name`,`t2`.`class_name` AS `class_name`,count(0) AS `COUNT(*)` from ((`db_school`.`tb_student` `t1` left join `db_school`.`tb_class` `t2` on((`t1`.`class_id` = `t2`.`class_id`))) left join `db_school`.`tb_teacher` `t3` on((`t2`.`teacher_id` = `t3`.`teacher_id`))) group by `t3`.`teacher_name`,`t2`.`class_name` having (count(0) > 5)
