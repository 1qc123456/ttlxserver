TYPE=VIEW
query=select `t3`.`mname` AS `mname`,`t1`.`nickname` AS `nickname`,`t2`.`score` AS `score`,`t2`.`content` AS `content` from ((`db_movie`.`t_user` `t1` join `db_movie`.`t_comment` `t2` on((`t1`.`uid` = `t2`.`uid`))) join `db_movie`.`t_movie` `t3` on((`t2`.`mid` = `t3`.`mid`)))
md5=80a6496151461d0245a8a28cbda98045
updatable=1
algorithm=0
definer_user=root
definer_host=localhost
suid=2
with_check_option=0
timestamp=2024-01-20 06:37:26
create-version=1
source=SELECT  t3.mname,t1.nickname,t2.score,t2.content FROM t_user t1 \nINNER JOIN  t_comment t2  ON t1.uid = t2.uid\nINNER JOIN t_movie t3 on t2.mid = t3.mid
client_cs_name=utf8mb4
connection_cl_name=utf8mb4_general_ci
view_body_utf8=select `t3`.`mname` AS `mname`,`t1`.`nickname` AS `nickname`,`t2`.`score` AS `score`,`t2`.`content` AS `content` from ((`db_movie`.`t_user` `t1` join `db_movie`.`t_comment` `t2` on((`t1`.`uid` = `t2`.`uid`))) join `db_movie`.`t_movie` `t3` on((`t2`.`mid` = `t3`.`mid`)))
