select t1.nickname,t2.mid,t2.score,t2.content from t_user t1  left JOIN t_comment t2  on t1.uid = t2.uid
WHERE t1.nickname = '白色';