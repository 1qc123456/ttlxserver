SELECT t2.mname,COUNT(*)  from t_comment t1 
	INNER JOIN t_movie t2 on  t1.mid = t2.mid 
	GROUP BY t2.mname;