// JavaScript Document
$(document).ready(function(){
	//导航
	var windowW=window.innerHeight;
	$(window).scroll(function(event){
		
        if($(window).scrollTop() >windowW){
            $(".return_top").addClass('on');
			$(".fwbg").addClass('on');
			
			//$('.dingGou').removeClass('on');
        }else{
            $(".return_top").removeClass('on');
			$(".fwbg").removeClass('on');

        }
    })
	
	
	$(window).on('ready load resize',function(event) {
		if(window.innerWidth>768){
			//一二级
			$('.pc_nav li').hover(function(){
				$(this).children('.erji_body').stop().slideDown(300);
				$(this).siblings('li').children('.erji_body').stop().slideUp(250);
			},function(){
				 $(this).children('.erji_body').stop().slideUp(250);
			})
			
			$(".inner_menu_lits").css('width', 'auto');
		}else{
			$('.mo_nav li>a').attr('href','javascript:;');
			$('.mo_nav .li_min').each(function(){
				var len = $(this).children('.sanji_body').children('a').length;
				if(len > 0){
					$(this).children('a').attr('href','javascript:;');
				}
			})
			
			//移动端内页菜单
			var sum = 0;
			$(".inner_menu_lits li").each(function(i) {
				sum += $(this).width();
			});
			$(".inner_menu_lits").css('width', sum);
		}
	})
	
	$('.mo_nav').html($('.pc_nav').html());
	$('.mo_header_top').html($('.pc_header_top').html());
	
		//移动端导航
		$('.mo_nav_btn').click(function(){
			$('.mo_header').toggleClass('on');
		})
		
		$('.mo_nav li>a').click(function(){
			$(this).parent('li').toggleClass('on').siblings('li').removeClass('on');
			$(this).siblings('.erji_body').stop().slideToggle();
			$(this).parent('li').siblings('li').children('.erji_body').stop().slideUp();
		})
		$('.li_min>a').click(function(){
			$(this).parent('.li_min').toggleClass('on').siblings('.li_min').removeClass('on');
			$(this).siblings('.sanji_body').stop().slideToggle();
			$(this).parent('.li_min').siblings('.li_min').children('.sanji_body').stop().slideUp();
		})
		
		
		/* footer-nav */
		/*
		$('.foo_nav_yiji').click(function(){
			$(this).parent('.foo_nav_wrap').parent('li').toggleClass('ons').siblings('li').removeClass('ons');
			$(this).siblings('.foo_nav_ejbody').stop().slideToggle();
			$(this).parent('.foo_nav_wrap').parent('li').siblings('li').find('.foo_nav_ejbody').stop().slideUp();
			$('.friendly_link dl').stop().slideUp();
			$('.friendly_link span').removeClass('ons');
		})
		*/
		/* foot-link */
		/*
		$('.friendly_link span').click(function(){
			$(this).toggleClass('ons');
			$(this).siblings('dl').slideToggle();
			$('.foo_nav_ejbody').slideUp();
			$('.foo_nav li').removeClass('ons');
		})
		*/
		
		//首页订购
		$('.modgbtn').click(function(){
			$('.dingGou').addClass('on');
		})
		$('.closedgbtn').click(function(){
			$('.dingGou').removeClass('on');
		})
	
	
	
	
	// 返回顶部
    $(".return_top").on('click', function(event) {
        $("html,body").animate({scrollTop:0}, 800);
        
    });

	
	//搜索焦点
	$(".ss_text").focus(function(event) {
        var user=$(this).val();
        if(user=="搜索"){
            $(this).val("");
        }
    }).blur(function(event) {
        if($(".ss_text").val()==""){
            $(".ss_text").val("搜索");
        }
    });
	
	$('.mo_ss').click(function(){
		$('.mo_ssbody').slideToggle();
	})

	
	
	//登录注册
	$('.login').click(function(){
		$('.login_hhl').addClass('on1');
	})
	$('.sign').click(function(){
		$('.login_hhl').addClass('on2');
	})
	$('.go_login').click(function(){
		$('.form_type').addClass('switching');
		$('.login_hhl').removeClass('on3');
		$('.login_hhl').removeClass('on2').addClass('on1');
		setTimeout(function () {
			$('.form_type').removeClass('switching');
		},810);
	})
	
	$('.go_sign').click(function(){
		$('.form_type').addClass('switching');
		$('.login_hhl').removeClass('on1').addClass('on2');
		setTimeout(function () {
			$('.form_type').removeClass('switching');
		},810);
	})
	
	$('.forget').click(function(){
		$('.form_type').addClass('switching');
		$('.login_hhl').removeClass('on1').addClass('on3');
		setTimeout(function () {
			$('.form_type').removeClass('switching');
		},810);
	})

	$('.close_login,.blank').click(function(){
		$('.login_hhl').removeClass('on1');
		$('.login_hhl').removeClass('on2');
		$('.login_hhl').removeClass('on3');
	})
	
	videonodown();
	// var lx = $('.index_part2').offset()['top'];
	// console.log(lx);
	// 
	
})
function videonodown(){
	$('video').bind('contextmenu',function() { return false; });
	$('video').attr('controlsList','nodownload');
}
function validate_form(form) {
	if(form.ProductKeyId.value=='0') {
	    //alert("请选择票类!");
	    swal({
		  title: "",
		  text: "请选择票类",
		  imageUrl: "../Public/Images/icon-error.png"
		});
	    form.ProductKeyId.focus();
	    return false;
	}
	if(form.num.value==''){
	    //alert("请输入人数!");
	    swal({
		  title: "",
		  text: "请输入人数",
		  imageUrl: "../Public/Images/icon-error.png"
		});
	    form.num.focus();
	    return false;
	}
	if(!(/^1[34578]\d{9}$/.test(form.phone.value))){
	    //alert("请输入手机号码!");
	    swal({
		  title: "",
		  text: "请输入手机号码",
		  imageUrl: "../Public/Images/icon-error.png"
		});
	    form.phone.focus();
	    return false;
	}
	if(form.date.value==''){
	    //alert("请输入预定日期!");
	    swal({
		  title: "",
		  text: "请输入预订日期",
		  imageUrl: "../Public/Images/icon-error.png"
		});
	    form.date.focus();
	    return false;
	}



}