TYPE=VIEW
query=select `db_bus`.`t_driver`.`sex` AS `sex`,count(0) AS `COUNT(*)`,round(avg(`db_bus`.`t_driver`.`salary`),2) AS `ROUND(AVG(salary),2)` from `db_bus`.`t_driver` group by `db_bus`.`t_driver`.`sex`
md5=5eb32bce8d53b4a0cfee328a089b2c8b
updatable=0
algorithm=0
definer_user=root
definer_host=localhost
suid=2
with_check_option=0
timestamp=2023-12-18 03:38:13
create-version=1
source=SELECT sex, COUNT(*),ROUND(AVG(salary),2)\nFROM t_driver\nGROUP BY sex
client_cs_name=utf8mb4
connection_cl_name=utf8mb4_general_ci
view_body_utf8=select `db_bus`.`t_driver`.`sex` AS `sex`,count(0) AS `COUNT(*)`,round(avg(`db_bus`.`t_driver`.`salary`),2) AS `ROUND(AVG(salary),2)` from `db_bus`.`t_driver` group by `db_bus`.`t_driver`.`sex`
