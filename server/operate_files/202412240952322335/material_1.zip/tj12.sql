SELECT o.oid as '订单ID',o.amount as '订单金额',o.ordertime as '下单时间',o.address as '收货地址',p.pname as '商品名称',p.price as '价格',oi.inum as '购买数量'
FROM orders o
JOIN orderitems oi ON o.oid = oi.oid
JOIN products p ON oi.pid = p.pid
WHERE o.username = '阿康';