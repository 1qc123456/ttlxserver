SELECT c.dname as '类别名称',AVG(p.price) as '平均价格',SUM(p.sale_qty) as '总销售数量'
FROM category c JOIN products p ON c.cid = p.cid
GROUP BY c.dname
ORDER BY SUM(p.sale_qty) desc;