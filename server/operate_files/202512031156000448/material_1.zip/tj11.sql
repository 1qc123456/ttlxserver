SELECT 
    sname AS '学生姓名',
    sex AS '性别',
		age as '年龄',
    phone AS '联系电话'
FROM tb_student
ORDER BY sex asc,age desc