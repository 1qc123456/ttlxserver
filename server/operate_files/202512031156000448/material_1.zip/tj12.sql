SELECT 
    s.sname AS '学生姓名',
    c.cname AS '班级名称',
    COUNT(DISTINCT sc.course_id) AS '已修课程数',
    SUM(cr.credit) AS '总学分',
    ROUND(AVG(sc.score), 2) AS '平均成绩'
FROM tb_student s
LEFT JOIN tb_class c ON s.cid = c.cid
LEFT JOIN tb_score sc ON s.sid = sc.sid AND sc.score >= 60
LEFT JOIN tb_course cr ON sc.course_id = cr.course_id
GROUP BY s.sid, s.sname, c.cname
HAVING COUNT(DISTINCT sc.course_id) >= 3
ORDER BY 平均成绩 DESC;