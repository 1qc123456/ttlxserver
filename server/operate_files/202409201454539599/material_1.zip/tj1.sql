select d.pName,a.pmTitle from poem a
join poemindex b on a.pmID=b.pmID
join poemtype c on b.ptID=c.ptID
join poet d on a.pID=d.pID
where d.pDynasty='宋' and c.ptType='主题' and c.ptName='爱国'