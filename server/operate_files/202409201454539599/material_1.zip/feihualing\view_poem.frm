TYPE=VIEW
query=select `a`.`pmTitle` AS `pmTitle`,`a`.`pmHot` AS `pmHot` from ((`feihualing`.`poem` `a` join `feihualing`.`poemling` `b` on((`a`.`pmID` = `b`.`pmID`))) join `feihualing`.`feihualing` `c` on((`b`.`fID` = `c`.`fID`))) where (`c`.`fName` = \'颜色\')
md5=701042b845758fd5c114daeb2a08d536
updatable=1
algorithm=0
definer_user=root
definer_host=localhost
suid=2
with_check_option=0
timestamp=2024-09-20 06:52:01
create-version=1
source=select a.pmTitle,a.pmHot from poem a\njoin poemling b on a.pmID=b.pmID\njoin feihualing c on b.fID=c.fID\nwhere c.fName=\'颜色\'
client_cs_name=utf8mb4
connection_cl_name=utf8mb4_general_ci
view_body_utf8=select `a`.`pmTitle` AS `pmTitle`,`a`.`pmHot` AS `pmHot` from ((`feihualing`.`poem` `a` join `feihualing`.`poemling` `b` on((`a`.`pmID` = `b`.`pmID`))) join `feihualing`.`feihualing` `c` on((`b`.`fID` = `c`.`fID`))) where (`c`.`fName` = \'颜色\')
