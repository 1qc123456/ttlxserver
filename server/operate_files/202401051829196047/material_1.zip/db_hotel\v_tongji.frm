TYPE=VIEW
query=select `t3`.`hname` AS `hname`,sum(`t2`.`price`) AS `SUM(price)` from ((`db_hotel`.`t_booking` `t1` left join `db_hotel`.`t_room` `t2` on((`t1`.`rid` = `t2`.`rid`))) left join `db_hotel`.`t_hotel` `t3` on((`t3`.`hid` = `t2`.`hid`))) group by `t3`.`hid`
md5=199cbbd3ac1a4ed40025309464796092
updatable=0
algorithm=0
definer_user=root
definer_host=localhost
suid=2
with_check_option=0
timestamp=2024-01-05 10:27:25
create-version=1
source=select t3.hname,SUM(price) from  t_booking t1 LEFT JOIN t_room t2 on t1.rid = t2.rid\n	LEFT JOIN t_hotel t3 on t3.hid = t2.hid  GROUP BY t3.hid
client_cs_name=utf8mb4
connection_cl_name=utf8mb4_general_ci
view_body_utf8=select `t3`.`hname` AS `hname`,sum(`t2`.`price`) AS `SUM(price)` from ((`db_hotel`.`t_booking` `t1` left join `db_hotel`.`t_room` `t2` on((`t1`.`rid` = `t2`.`rid`))) left join `db_hotel`.`t_hotel` `t3` on((`t3`.`hid` = `t2`.`hid`))) group by `t3`.`hid`
