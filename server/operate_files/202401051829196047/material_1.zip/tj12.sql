	SELECT t1.hname,t2.price from t_hotel t1 INNER JOIN (
	select hid,price from t_room   where rname = '大床房'  ORDER BY price desc LIMIT 1) t2 on t1.hid = t2.hid;