	SELECT t1.hname,t2.rname,t2.price from t_hotel t1 INNER JOIN (
	SELECT * from t_room where rid not in (SELECT rid from t_booking GROUP BY rid)) t2 on t1.hid = t2.hid;