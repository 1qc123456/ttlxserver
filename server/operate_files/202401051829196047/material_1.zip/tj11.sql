	select  t3.cname,SUM(price) totalPrice from  t_booking t1 LEFT JOIN t_room t2 on t1.rid = t2.rid
	LEFT JOIN t_client t3 on t3.cid = t1.cid
	GROUP BY t1.cid  order by totalPrice desc LIMIT 9,1