TYPE=VIEW
query=select `s`.`name` AS `学生姓名`,`c`.`name` AS `班级`,`co`.`name` AS `科目名称`,`g`.`score` AS `分数` from (((`db_grade`.`t_student` `s` join `db_grade`.`t_class` `c` on((`s`.`cla_id` = `c`.`id`))) join `db_grade`.`t_grade` `g` on((`s`.`id` = `g`.`stu_id`))) join `db_grade`.`t_course` `co` on((`g`.`cou_id` = `co`.`id`)))
md5=ee010f4760fb62d6f13428c0c7ed04a3
updatable=1
algorithm=0
definer_user=root
definer_host=localhost
suid=2
with_check_option=0
timestamp=2024-05-07 02:46:54
create-version=1
source=SELECT s.name AS 学生姓名, c.name AS 班级, co.name AS 科目名称, g.score AS 分数  \nFROM t_student s  \nJOIN t_class c ON s.cla_id = c.id  \nJOIN t_grade g ON s.id = g.stu_id  \nJOIN t_course co ON g.cou_id = co.id
client_cs_name=utf8mb4
connection_cl_name=utf8mb4_general_ci
view_body_utf8=select `s`.`name` AS `学生姓名`,`c`.`name` AS `班级`,`co`.`name` AS `科目名称`,`g`.`score` AS `分数` from (((`db_grade`.`t_student` `s` join `db_grade`.`t_class` `c` on((`s`.`cla_id` = `c`.`id`))) join `db_grade`.`t_grade` `g` on((`s`.`id` = `g`.`stu_id`))) join `db_grade`.`t_course` `co` on((`g`.`cou_id` = `co`.`id`)))
