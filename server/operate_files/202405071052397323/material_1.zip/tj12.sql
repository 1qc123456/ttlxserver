SELECT s.name AS 学生姓名, SUM(g.score) AS 总分  
FROM t_student s   
JOIN t_grade g ON s.id = g.stu_id  
GROUP BY s.id