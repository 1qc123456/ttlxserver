TYPE=VIEW
query=select `t1`.`name` AS `学生姓名`,sum(`t2`.`score`) AS `总分` from (`db_class`.`t_student` `t1` join `db_class`.`t_score` `t2` on((`t1`.`id` = `t2`.`stuid`))) group by `t1`.`name` having (sum(`t2`.`score`) > 250) order by sum(`t2`.`score`) desc
md5=200ab8f8b3df8f160b399cc39fbf1afe
updatable=0
algorithm=0
definer_user=root
definer_host=localhost
suid=2
with_check_option=0
timestamp=2024-10-21 05:04:13
create-version=1
source=select t1.name as \'学生姓名\',sum(t2.score) as \'总分\'\nfrom t_student t1 join t_score t2 on t1.id = t2.stuid\ngroup by t1.name\nhaving sum(t2.score) > 250\norder by sum(t2.score) desc
client_cs_name=utf8mb4
connection_cl_name=utf8mb4_general_ci
view_body_utf8=select `t1`.`name` AS `学生姓名`,sum(`t2`.`score`) AS `总分` from (`db_class`.`t_student` `t1` join `db_class`.`t_score` `t2` on((`t1`.`id` = `t2`.`stuid`))) group by `t1`.`name` having (sum(`t2`.`score`) > 250) order by sum(`t2`.`score`) desc
