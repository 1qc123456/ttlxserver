select t1.name as '学生姓名',t3.name as '学科名称',case
when t2.score < 90 then 'D'
when t2.score < 110 then 'C'
when t2.score < 130 then 'B'
when t2.score >= 130 then 'A'
end as '学生成绩'
from t_student t1 join t_score t2 on t1.id = t2.stuid
join t_subject t3 on t2.subid = t3.id;