select t1.name as '班级名称',count(distinct t2.stuid)as '人数'
from t_class t1 join t_score t2 on t1.id = t2.claid
join t_student t3 on t2.stuid = t3.id
group by t1.name
order by count(distinct t2.stuid) desc;