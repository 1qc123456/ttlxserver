TYPE=VIEW
query=select `t1`.`bno` AS `bno`,`t2`.`cname` AS `cname`,`t1`.`rooms` AS `rooms` from (`db_booking`.`tb_booking` `t1` left join `db_booking`.`tb_customers` `t2` on((`t1`.`cno` = `t2`.`cno`)))
md5=57e5452d4eb895387ae1e42f2f7a37af
updatable=0
algorithm=0
definer_user=root
definer_host=localhost
suid=2
with_check_option=0
timestamp=2023-11-03 01:56:20
create-version=1
source=select t1.bno,t2.cname,t1.rooms from tb_booking t1\nleft join tb_customers t2\non t1.cno=t2.cno
client_cs_name=gbk
connection_cl_name=gbk_chinese_ci
view_body_utf8=select `t1`.`bno` AS `bno`,`t2`.`cname` AS `cname`,`t1`.`rooms` AS `rooms` from (`db_booking`.`tb_booking` `t1` left join `db_booking`.`tb_customers` `t2` on((`t1`.`cno` = `t2`.`cno`)))
