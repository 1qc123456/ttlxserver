SELECT 
    tb_grade.gname,
    SUM(tb_car_inventory.inventory_quantity) AS total_inventory,
    MIN(tb_car_inventory.inventory_quantity) AS min_inventory,
    MAX(tb_car_inventory.inventory_quantity) AS max_inventory,
    CASE
        WHEN SUM(tb_car_inventory.inventory_quantity) > 500 THEN '高库存'
        WHEN SUM(tb_car_inventory.inventory_quantity) >= 200 THEN '中库存'
        ELSE '低库存'
    END AS stock_status
FROM 
    tb_grade
JOIN 
    tb_cars ON tb_grade.gid = tb_cars.gid
JOIN 
    tb_car_inventory ON tb_cars.cid = tb_car_inventory.cid
GROUP BY 
    tb_grade.gname;