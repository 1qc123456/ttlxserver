SELECT 
    g.gname AS '汽车等级名称',
    ROUND(AVG(s.sale_price), 2) AS '平均销售单价',
    COUNT(DISTINCT s.cid) AS '有销售记录的汽车种类数'
FROM tb_grade g
LEFT JOIN tb_cars c ON g.gid = c.gid
LEFT JOIN tb_sales_records s ON c.cid = s.cid
GROUP BY g.gid, g.gname
ORDER BY 平均销售单价 DESC;