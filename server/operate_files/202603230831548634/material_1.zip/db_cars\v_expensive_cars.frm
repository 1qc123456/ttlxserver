TYPE=VIEW
query=select `c`.`cname` AS `汽车名称`,`s`.`sale_price` AS `销售单价`,`s`.`sale_date` AS `销售日期` from (`db_cars`.`tb_sales_records` `s` join `db_cars`.`tb_cars` `c` on((`s`.`cid` = `c`.`cid`))) where (`s`.`sale_price` > 500000) order by `s`.`sale_price` desc
md5=c744cae53be94608ab4bac852937d991
updatable=1
algorithm=0
definer_user=root
definer_host=localhost
suid=1
with_check_option=0
timestamp=2026-03-13 07:16:35
create-version=1
source=SELECT\n	`c`.`cname` AS `汽车名称`,\n	`s`.`sale_price` AS `销售单价`,\n	`s`.`sale_date` AS `销售日期` \nFROM\n	(\n		`tb_sales_records` `s`\n		JOIN `tb_cars` `c` ON ((\n				`s`.`cid` = `c`.`cid` \n			))) \nWHERE\n	( `s`.`sale_price` > 500000 ) \nORDER BY\n	`s`.`sale_price` DESC
client_cs_name=utf8mb4
connection_cl_name=utf8mb4_general_ci
view_body_utf8=select `c`.`cname` AS `汽车名称`,`s`.`sale_price` AS `销售单价`,`s`.`sale_date` AS `销售日期` from (`db_cars`.`tb_sales_records` `s` join `db_cars`.`tb_cars` `c` on((`s`.`cid` = `c`.`cid`))) where (`s`.`sale_price` > 500000) order by `s`.`sale_price` desc
