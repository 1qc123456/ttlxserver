TYPE=VIEW
query=select `e`.`ename` AS `职工姓名`,`d`.`dname` AS `部门名称`,`s`.`insurance` AS `养老保险` from ((`db_salary`.`t_department` `d` join `db_salary`.`t_employee` `e` on((`d`.`dno` = `e`.`dno`))) join `db_salary`.`t_salary` `s` on((`e`.`eno` = `s`.`eno`))) where (month(`s`.`salarydate`) = 9) order by `s`.`insurance` desc
md5=3b4cbc03b4b9a050fe5c1cc37de4ada0
updatable=1
algorithm=0
definer_user=root
definer_host=localhost
suid=1
with_check_option=0
timestamp=2025-10-27 07:04:37
create-version=1
source=select e.ename as \'职工姓名\',d.dname as \'部门名称\',s.insurance as \'养老保险\'\nfrom t_department d join t_employee e on d.dno = e.dno\njoin t_salary s on e.eno = s.eno\nwhere month(salarydate) = 9\norder by s.insurance desc
client_cs_name=utf8mb4
connection_cl_name=utf8mb4_general_ci
view_body_utf8=select `e`.`ename` AS `职工姓名`,`d`.`dname` AS `部门名称`,`s`.`insurance` AS `养老保险` from ((`db_salary`.`t_department` `d` join `db_salary`.`t_employee` `e` on((`d`.`dno` = `e`.`dno`))) join `db_salary`.`t_salary` `s` on((`e`.`eno` = `s`.`eno`))) where (month(`s`.`salarydate`) = 9) order by `s`.`insurance` desc
