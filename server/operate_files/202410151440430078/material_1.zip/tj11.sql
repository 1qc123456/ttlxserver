select e.*,d.dname
from t_employee e join t_department d on e.dno = d.dno
where d.dname = '研发部';