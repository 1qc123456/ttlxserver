select e.eno as '职工编号',e.ename as '职工姓名',s.basepay+s.overtime as '职工工资'
from t_employee e join t_salary s on e.eno = s.eno
where month(salarydate) = 9;