//截取URL域名部份
var getHost = function(url) {
	var host = "null";
	if (typeof url == "undefined" || null == url) url = window.location.host;
	var regex = /^\/[\w\/]*/;
	var match = url.match(regex);
	if (typeof match != "undefined" && null != match) host = window.location.host;
	return host;
};
$(document).ready(function () {
	$("a").click(function(){
		var o = $(this);
		var url = o.attr('href');
		var host = getHost(url);
		if (host.indexOf("hsgwh.huangshan.gov.cn") == -1 && url.indexOf("hsgwh.huangshan.gov.cn") == -1 && url.indexOf("hsgwh.huangshan.gov.cn") == -1 && url.indexOf("javascript") && url != "#"){
			$(this).attr('target','_self');
			$(this).attr('href','javascript:void(0)');
			var w = '480px';
			var h = '170px';
			if(window.screen.width < 768) { w = '90%'; h = '170px';}
			var cf = layer.confirm('<div style="margin-top:30px; font-size:16px;">您访问的链接即将离开“中国黄山风景名胜区”，将访问外部链接地址为' + url + '是否继续？</div>', {
				btn:[ '继续访问', '放弃' ],
				title: false,
				shade: 0.7,
				area: [w, h],
				cancel: function(index){ o.attr('href',url); }
			}, function() {
				window.open(url); 
				o.attr('href',url);
				layer.close(cf);
			}, function() {
				o.attr('href',url);
			});
		}
	});
	
	$('.m-select select').change(function(){ 
		var ob = $(this).children('option:selected');
		var url1 = ob.val();
		var host1 = getHost(url1);
		if (host1.indexOf(".gov.cn") == -1 && url1.indexOf(".gov.cn") == -1 && url1.indexOf("javascript") && url1 != "#"){
			ob.attr('target','_self');
			ob.attr('value','#');
			var w1 = '480px';
			var h1 = '170px';
			if(window.screen.width < 768) { w1 = '90%'; h1 = '170px';}
			var cf1 = layer.confirm('<div style="margin-top:30px; font-size:16px;">您访问的链接即将离开“中国黄山风景名胜区” 是否继续？</div>', {
				btn:[ '继续访问', '放弃' ],
				title: false,
				shade: 0.7,
				area: [w1, h1],
				cancel: function(index){ ob.attr('value',url1); }
			}, function() {
				window.open(url1); 
				ob.attr('value',url1);
				layer.close(cf1);
			}, function() {
				ob.attr('value',url1);
			});
		}else{
			window.open(url1); 
		}
	}) 
	
});

function jumpPrompt(url) {
    var o = $(this);
    var host = getHost(url);
        $(this).attr('target','_self');
        //$(this).attr('href','javascript:void(0)');
        var w = '480px';
        var h = '170px';
        if(window.screen.width < 768) { w = '90%'; h = '170px';}
        var cf = layer.confirm('<div style="margin-top:30px; font-size:16px;">网站留言需跳转至安徽政务服务网统一认证中心登入，是否继续？</div>', {
            btn:[ '确定', '取消' ],
            title: false,
            shade: 0.7,
            area: [w, h],
            cancel: function(index){ o.attr('href',url); }
        }, function() {
            window.open(url);
            o.attr('href',url);
            layer.close(cf);
        }, function() {
            o.attr('href',url);
        });
}
