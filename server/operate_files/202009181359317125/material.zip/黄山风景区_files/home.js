 //加入收藏
         
                function AddFavorite(sURL, sTitle) {
         
                    sURL = encodeURI(sURL); 
                try{   
         
                    window.external.addFavorite(sURL, sTitle);   
         
                }catch(e) {   
         
                    try{   
         
                        window.sidebar.addPanel(sTitle, sURL, "");   
         
                    }catch (e) {   
         
                        alert("加入收藏失败，请使用Ctrl+D进行添加,或手动在浏览器里进行设置.");
         
                    }   
         
                }
          
            }
         
            //设为首页
function SetHome(url){
    if (document.all) {
        document.body.style.behavior='url(#default#homepage)';
           document.body.setHomePage(url);
    }else{
        alert("您好,您的浏览器不支持自动设置页面为首页功能,请您手动在浏览器里设置该页面为首页!");
    }
}

$(".xwzx-box5 li").hover(function(){
    $(this).removeClass("hd");
    $(this).find("span").stop().animate({
        opacity:1
    },600);
},function(){
    $(this).addClass("hd");
    $(this).find("span").stop().animate({
        opacity:0
    },200);

});

$(function(){

	//获取黄山美景图片高度，设置line-height;
	var $showLi = $(".is-show li");
	for(var i=0;i<$showLi.length;i++){
		var h = $showLi.eq(i).height();
		// console.log(h);
		$showLi.eq(i).find("p").css("line-height",h+"px");
	}

   

	var index=0,len=$('.tabnav li').length,_timer=null;  
	
	function showTab(index){			
		$('.tabnav li').eq(index).addClass('cur').siblings().removeClass('cur');				 
		$('.tabcon li').eq(index).stop(true,true).slideDown('slow').siblings().slideUp('slow');
	}
	
	function auto(){
		timer=setTimeout(function(){
			index=(index+1)%len;
			showTab(index);
			timer=setTimeout(arguments.callee,3500);
		},1000)	
	}
	
	auto(); 
	
	$('.tabnav li').mouseenter(function(){
		var index=$(this).index(); 
		showTab(index);	 
	});
	
	$('.acttabbox').hover(function(){
		clearTimeout(timer);
	},function(){
		auto();
	});



	$(".is-asideBtn").click(function(){
		$(".is-asideBtn").animate({
			opacity: "0"
		},100);
		$(".is-aside").animate({
			height: "590px"
		},1000);
	});

	$(".is-aside .asideBox1 h2").click(function(){
		$(".is-aside").animate({
			height: "0"
		},500);
		$(".is-asideBtn").animate({
			opacity: "1"
		},520);
	});
	
				

});

	
	// 背景图片
	$(function(){
		$('.m-bgflash .bd ul li:eq(0)').show();
		var speed = 9000,iNum = 0;
		var autoPlay = function(){
			iNum++;
			if(iNum == $('.m-bgflash .bd ul li').length){
				iNum=0;
			}
			$('.m-bgflash .bd ul li').fadeOut(1000).eq(iNum).fadeIn(1000);		
		};
		var timer = setInterval(autoPlay,speed);
	});
//Title提示美化
jQuery(document).ready(function($) {
    var sweetTitles = {
        x: 10,
        y: 20,
        tipElements: "a",
        noTitle: false,
        init: function() {
            var noTitle = this.noTitle;
            $(this.tipElements).each(function() {
                $(this).mouseover(function(e) {
                    if (noTitle) {
                        isTitle = true;
                    } else {
                        isTitle = $.trim(this.title) != '';
                    }
                    if (isTitle) {
                        this.myTitle = this.title;
                        this.title = "";
                        var tooltip = "<div class='tooltip'><div class='tipsy-arrow tipsy-arrow-n'></div><div class='tipsy-inner'>" + this.myTitle + "</div></div>";
                        $('body').append(tooltip);
                        $('.tooltip').css({
                            "top": (e.pageY + 20) + "px",
                            "left": (e.pageX - 20) + "px"
                        }).show('fast');
                    }
                }).mouseout(function() {
                    if (this.myTitle != null) {
                        this.title = this.myTitle;
                        $('.tooltip').remove();
                    }
                }).mousemove(function(e) {
                    $('.tooltip').css({
                        "top": (e.pageY + 20) + "px",
                        "left": (e.pageX - 20) + "px"
                    });
                });
            });
        }
    };
    $(function() {
        sweetTitles.init();
    });
});
	