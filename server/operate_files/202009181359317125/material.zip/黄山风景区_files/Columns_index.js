function killerrors() { 
return true; 
} 
window.onerror = killerrors; 



function isShowIndex(tab_id,div_id,who,aId,aHref,num){
   for(var i = 0;i < num;i++){
      document.getElementById("dt"+who+i).style.display="none";
      document.getElementById("sp"+who+i).className="aoff";
   }
   document.getElementById(div_id).style.display="block";
   document.getElementById(tab_id).className="aon";
 document.getElementById(aId).href = aHref;
}


$(function(){
   changeSelect();
})

function changeSelect() {
   var url = window.location.href;
   if(url.indexOf("News") >= 0){
      $('#xiaoguo>li').removeAttr("class","u-active");
      $('#xiaoguo').children("li").eq(1).addClass("u-active");
   }else if(url.indexOf("Openness") >= 0){
      $('#xiaoguo>li').removeAttr("class","u-active");
      $('#xiaoguo').children("li").eq(2).addClass("u-active");
   }else if(url.indexOf("About") >= 0){
      $('#xiaoguo>li').removeAttr("class","u-active");
      $('#xiaoguo').children("li").eq(3).addClass("u-active");
   }else if(url.indexOf("Travel") >= 0){
      $('#xiaoguo>li').removeAttr("class","u-active");
      $('#xiaoguo').children("li").eq(4).addClass("u-active");
   }else if(url.indexOf("Interaction") >= 0){
      $('#xiaoguo>li').removeAttr("class","u-active");
      $('#xiaoguo').children("li").eq(6).addClass("u-active");
   }else{
	  $('#xiaoguo>li').removeAttr("class","u-active");
      $('#xiaoguo').children("li").eq(0).addClass("u-active");
   }

}





