$(function(){
    $(".is-dynamic .top a, .is-flinks .top a, .is-panel1 .top a").mouseover(function(){
    var tabTitle = $(this).parent();
    var tabContent = tabTitle.parent().siblings(".tab_content");
    var tabIndex = tabTitle.children("a").index(this);
    tabTitle.children(".hover").removeClass("hover");
    $(this).addClass("hover");
    tabContent.children(".current").removeClass("current");
    tabContent.children("div").eq(tabIndex).addClass("current");
    });


    $(".is-hswj .box .top a").mouseover(function(){
    var tabTitle = $(this).parent();
    var tabContent = tabTitle.parent().siblings(".tab_content");
    var tabIndex = tabTitle.children("a").index(this);
    tabTitle.children(".hover").removeClass("hover");
    $(this).addClass("hover");
    tabContent.children(".current").removeClass("current");
    tabContent.children("span").eq(tabIndex).addClass("current");
    });



    $(".is-terrace .top a").mouseover(function(){
    var tabTitle = $(this).parent();
    var tabContent = tabTitle.siblings(".tab_content");
    var tabIndex = tabTitle.children("a").index(this);
    tabTitle.children(".hover").removeClass("hover");
    $(this).addClass("hover");
    tabContent.children(".current").removeClass("current");
    tabContent.children("div").eq(tabIndex).addClass("current");
    });

})



