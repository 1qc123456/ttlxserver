		SELECT   
    mname '会员姓名',  
    CASE  
        WHEN integral >= 10000 THEN '铂金会员'  
        WHEN integral >=5000 THEN '黄金会员'  
				WHEN integral >=3000 THEN '白银会员'  
        ELSE '青铜会员'  
    END AS 会员等级
FROM   
    t_member; 