TYPE=VIEW
query=select `t2`.`tid` AS `tid`,`t2`.`tname` AS `tname`,sum(`t1`.`price`) AS `totalPrice` from (`db_gym`.`t_course` `t1` left join `db_gym`.`t_trainer` `t2` on((`t1`.`tid` = `t2`.`tid`))) group by `t2`.`tid`,`t2`.`tname` order by `totalPrice` desc
md5=f2126ed5a9ed0e59cae0888ffc51f4c0
updatable=0
algorithm=0
definer_user=root
definer_host=localhost
suid=2
with_check_option=0
timestamp=2023-12-27 08:27:05
create-version=1
source=SELECT t2.tid,t2.tname,SUM(price) as totalPrice from t_course t1  \n	LEFT JOIN t_trainer t2 on t1.tid = t2.tid \n	GROUP BY t2.tid,t2.tname \n	ORDER BY totalPrice desc
client_cs_name=utf8mb4
connection_cl_name=utf8mb4_general_ci
view_body_utf8=select `t2`.`tid` AS `tid`,`t2`.`tname` AS `tname`,sum(`t1`.`price`) AS `totalPrice` from (`db_gym`.`t_course` `t1` left join `db_gym`.`t_trainer` `t2` on((`t1`.`tid` = `t2`.`tid`))) group by `t2`.`tid`,`t2`.`tname` order by `totalPrice` desc
