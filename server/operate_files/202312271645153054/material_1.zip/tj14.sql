SELECT t1.mid,t3.mname,t2.tname,t1.period,price FROM t_course  t1  
	LEFT JOIN t_trainer t2 on t1.tid = t2.tid 
	LEFT JOIN t_member t3 on t1.mid = t3.mid  
	WHERE t2.tname = '熊晓明';