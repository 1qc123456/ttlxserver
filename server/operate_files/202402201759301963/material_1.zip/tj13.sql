SELECT t2.ono '订单编号',t1.gname '商品名称', t1.price*t2.num  '总价',otime '订单时间' 
	from t_goods t1 
	INNER JOIN t_order t2 
	ON t1.gno = t2.gno;