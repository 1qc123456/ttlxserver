SELECT t1.cno,t1.cname,t2.ono,t2.gno,t2.num,t2.otime FROM t_customer t1 
	INNER JOIN t_order t2 on t1.cno = t2.cno
	where t1.cname = '龙睿'
	ORDER BY otime DESC;
