TYPE=VIEW
query=select `t2`.`ono` AS `ono`,`t1`.`cname` AS `cname`,`t3`.`gname` AS `gname`,`t2`.`num` AS `num`,`t2`.`otime` AS `otime` from ((`db_shop`.`t_customer` `t1` join `db_shop`.`t_order` `t2` on((`t1`.`cno` = `t2`.`cno`))) join `db_shop`.`t_goods` `t3` on((`t3`.`gno` = `t2`.`gno`))) order by `t2`.`otime` desc limit 49,31
md5=88663eeba27432cb5dcbd9c04f9361c6
updatable=0
algorithm=0
definer_user=root
definer_host=localhost
suid=1
with_check_option=0
timestamp=2024-02-21 06:00:05
create-version=1
source=select `t2`.`ono` AS `ono`,`t1`.`cname` AS `cname`,`t3`.`gname` AS `gname`,`t2`.`num` AS `num`,`t2`.`otime` AS `otime` from ((`t_customer` `t1` join `t_order` `t2` on((`t1`.`cno` = `t2`.`cno`))) join `t_goods` `t3` on((`t3`.`gno` = `t2`.`gno`))) order by `t2`.`otime` desc limit 49,31
client_cs_name=utf8mb4
connection_cl_name=utf8mb4_general_ci
view_body_utf8=select `t2`.`ono` AS `ono`,`t1`.`cname` AS `cname`,`t3`.`gname` AS `gname`,`t2`.`num` AS `num`,`t2`.`otime` AS `otime` from ((`db_shop`.`t_customer` `t1` join `db_shop`.`t_order` `t2` on((`t1`.`cno` = `t2`.`cno`))) join `db_shop`.`t_goods` `t3` on((`t3`.`gno` = `t2`.`gno`))) order by `t2`.`otime` desc limit 49,31
