SELECT  gname AS '商品名称', t_goods.type AS '商品类型',price '价格'   
FROM t_goods   
JOIN (  
    SELECT MIN(price) AS min_price, type   
    FROM t_goods   
    GROUP BY type  
) t ON t_goods.type = t.type and t_goods.price = min_price;