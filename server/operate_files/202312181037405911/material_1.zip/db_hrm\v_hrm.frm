TYPE=VIEW
query=select `t2`.`dname` AS `dname`,`t1`.`ename` AS `ename`,`t3`.`money` AS `money`,`t3`.`stime` AS `stime` from ((`db_hrm`.`t_employee` `t1` join `db_hrm`.`t_department` `t2` on((`t1`.`did` = `t2`.`did`))) join `db_hrm`.`t_salary` `t3` on((`t1`.`eid` = `t3`.`eid`))) order by `t3`.`stime` desc
md5=eca3bc04e73f74ec837dbfd5a3d3433b
updatable=1
algorithm=0
definer_user=root
definer_host=localhost
suid=2
with_check_option=0
timestamp=2023-12-18 02:30:22
create-version=1
source=SELECT\nt2.dname,\nt1.ename,\nt3.money,\nt3.stime \nFROM\n	t_employee t1\n	JOIN t_department t2 ON t1.did = t2.did\n	JOIN t_salary t3 ON t1.eid = t3.eid \nORDER BY\n	stime DESC
client_cs_name=utf8mb4
connection_cl_name=utf8mb4_general_ci
view_body_utf8=select `t2`.`dname` AS `dname`,`t1`.`ename` AS `ename`,`t3`.`money` AS `money`,`t3`.`stime` AS `stime` from ((`db_hrm`.`t_employee` `t1` join `db_hrm`.`t_department` `t2` on((`t1`.`did` = `t2`.`did`))) join `db_hrm`.`t_salary` `t3` on((`t1`.`eid` = `t3`.`eid`))) order by `t3`.`stime` desc
