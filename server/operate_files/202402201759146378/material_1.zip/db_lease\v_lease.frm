TYPE=VIEW
query=select `c`.`name` AS `customer_name`,`h`.`address` AS `address`,`h`.`price` AS `monthly_price`,`o`.`time` AS `lease_time`,`o`.`duration` AS `lease_duration` from ((`db_lease`.`t_client` `c` join `db_lease`.`t_order` `o` on((`c`.`cid` = `o`.`cid`))) join `db_lease`.`t_house` `h` on((`o`.`hid` = `h`.`hid`)))
md5=ec94c0eb4164b89576f2200aa6cc5956
updatable=1
algorithm=0
definer_user=root
definer_host=localhost
suid=2
with_check_option=0
timestamp=2024-02-01 01:33:46
create-version=1
source=SELECT c.name AS customer_name, h.address, h.price AS monthly_price, o.time AS lease_time, o.duration AS lease_duration  \nFROM t_client c  \nJOIN t_order o ON c.cid = o.cid  \nJOIN t_house h ON o.hid = h.hid
client_cs_name=utf8mb4
connection_cl_name=utf8mb4_general_ci
view_body_utf8=select `c`.`name` AS `customer_name`,`h`.`address` AS `address`,`h`.`price` AS `monthly_price`,`o`.`time` AS `lease_time`,`o`.`duration` AS `lease_duration` from ((`db_lease`.`t_client` `c` join `db_lease`.`t_order` `o` on((`c`.`cid` = `o`.`cid`))) join `db_lease`.`t_house` `h` on((`o`.`hid` = `h`.`hid`)))
