SELECT
	t1.oid,
	t2.price,
	t1.duration,
	t2.price * t1.duration AS total_amount 
FROM
	t_order t1
	JOIN t_house t2 ON t1.hid = t2.hid;