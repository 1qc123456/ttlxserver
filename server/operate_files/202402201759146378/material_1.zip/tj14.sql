SELECT
	t_house.tel '房东电话' 
FROM
	t_client
	JOIN t_order ON t_order.cid = t_client.cid
	JOIN t_house ON t_house.hid = t_order.hid 
WHERE
	NAME = '沈杰宏';