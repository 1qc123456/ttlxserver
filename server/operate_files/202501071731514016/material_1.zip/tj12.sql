SELECT s.name AS 学生姓名, c.name AS 课程名称, l.schedule AS 学习进度  
FROM t_student s  
JOIN t_learn l ON s.id = l.s_id  
JOIN t_course c ON l.c_id = c.id  
WHERE s.name = '吴杰宏';