TYPE=VIEW
query=select `b`.`genre` AS `genre`,`a`.`author_name` AS `author_name`,count(0) AS `book_count` from ((`db_books`.`tb_books` `b` join `db_books`.`tb_book_authors` `ba` on((`b`.`book_id` = `ba`.`book_id`))) join `db_books`.`tb_authors` `a` on((`ba`.`author_id` = `a`.`author_id`))) group by `b`.`genre`,`a`.`author_name` having (count(0) = (select max(`subquery`.`book_count`) from (select `b`.`genre` AS `genre`,count(0) AS `book_count` from ((`db_books`.`tb_books` `b` join `db_books`.`tb_book_authors` `ba` on((`b`.`book_id` = `ba`.`book_id`))) join `db_books`.`tb_authors` `a` on((`ba`.`author_id` = `a`.`author_id`))) group by `b`.`genre`,`a`.`author_name`) `subquery` where (`subquery`.`genre` = `b`.`genre`)))
md5=90d7d4f0f3822a2ab68b9302e1331c0f
updatable=0
algorithm=0
definer_user=root
definer_host=localhost
suid=2
with_check_option=0
timestamp=2023-12-07 07:09:59
create-version=1
source=SELECT b.genre, a.author_name, COUNT(*) AS book_count\nFROM tb_books b\nJOIN tb_book_authors ba ON b.book_id = ba.book_id\nJOIN tb_authors a ON ba.author_id = a.author_id\nGROUP BY b.genre, a.author_name\nHAVING COUNT(*) = (\n  SELECT MAX(book_count)\n  FROM (\n    SELECT b.genre, COUNT(*) AS book_count\n    FROM tb_books b\n    JOIN tb_book_authors ba ON b.book_id = ba.book_id\n    JOIN tb_authors a ON ba.author_id = a.author_id\n    GROUP BY b.genre, a.author_name\n  ) subquery\n  WHERE subquery.genre = b.genre\n)
client_cs_name=utf8mb4
connection_cl_name=utf8mb4_general_ci
view_body_utf8=select `b`.`genre` AS `genre`,`a`.`author_name` AS `author_name`,count(0) AS `book_count` from ((`db_books`.`tb_books` `b` join `db_books`.`tb_book_authors` `ba` on((`b`.`book_id` = `ba`.`book_id`))) join `db_books`.`tb_authors` `a` on((`ba`.`author_id` = `a`.`author_id`))) group by `b`.`genre`,`a`.`author_name` having (count(0) = (select max(`subquery`.`book_count`) from (select `b`.`genre` AS `genre`,count(0) AS `book_count` from ((`db_books`.`tb_books` `b` join `db_books`.`tb_book_authors` `ba` on((`b`.`book_id` = `ba`.`book_id`))) join `db_books`.`tb_authors` `a` on((`ba`.`author_id` = `a`.`author_id`))) group by `b`.`genre`,`a`.`author_name`) `subquery` where (`subquery`.`genre` = `b`.`genre`)))
