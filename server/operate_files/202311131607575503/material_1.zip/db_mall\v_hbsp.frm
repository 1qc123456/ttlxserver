TYPE=VIEW
query=select `db_mall`.`tb_commodity`.`cno` AS `cno`,`db_mall`.`tb_commodity`.`cname` AS `cname`,`db_mall`.`tb_commodity`.`ctype` AS `ctype`,`db_mall`.`tb_commodity`.`origim` AS `origim`,`db_mall`.`tb_commodity`.`pd` AS `pd`,`db_mall`.`tb_commodity`.`price` AS `price` from `db_mall`.`tb_commodity` where ((`db_mall`.`tb_commodity`.`origim` = \'湖北\') and (`db_mall`.`tb_commodity`.`pd` > \'2018-01-01\'))
md5=4fa54b5948bcf097e95a6c4a4b7a1c02
updatable=1
algorithm=0
definer_user=root
definer_host=localhost
suid=2
with_check_option=0
timestamp=2023-11-13 05:34:37
create-version=1
source=SELECT * from tb_commodity  where origim = \'湖北\' and pd > \'2018-01-01\'
client_cs_name=utf8mb4
connection_cl_name=utf8mb4_general_ci
view_body_utf8=select `db_mall`.`tb_commodity`.`cno` AS `cno`,`db_mall`.`tb_commodity`.`cname` AS `cname`,`db_mall`.`tb_commodity`.`ctype` AS `ctype`,`db_mall`.`tb_commodity`.`origim` AS `origim`,`db_mall`.`tb_commodity`.`pd` AS `pd`,`db_mall`.`tb_commodity`.`price` AS `price` from `db_mall`.`tb_commodity` where ((`db_mall`.`tb_commodity`.`origim` = \'湖北\') and (`db_mall`.`tb_commodity`.`pd` > \'2018-01-01\'))
