$(function(){
	$('.a_ul_nav li').hover(function(){
		$(this).find('.lia').css({'background':'#00ab2f','color':'#fff'});
		$(this).find('.subnav').stop(true,true).slideDown(500);
	},function(){
		$(this).find('.lia').css({'background':'none','color':'#006fae'});
		$(this).find('.subnav').stop(true,true).slideUp(200);
	});

	$('.c_but ul li a').hover(function(){
		//$(this).addClass('color');
		$(this).find('i').addClass('animated zoomIn');
	},function(){
		//$(this).removeClass('color');
		$(this).find('i').removeClass('animated zoomIn');
	});

	$(".c_s_pic").slide({titCell:".hd ul",mainCell:".bd ul",autoPage:true,effect:"left",autoPlay:true,vis:4,trigger:"click"});

	$(".e_s_news").slide({titCell:".hd ul",mainCell:".bd ul",autoPage:true,effect:"left",autoPlay:true,vis:3,trigger:"click"});

	$('.c_s_pic .bd ul li').hover(function(){
		$(this).find('em').addClass('no');
		$(this).find('div').stop(true,true).animate({'top':'0'});
	},function(){
		$(this).find('em').removeClass('no');
		$(this).find('div').stop(true,true).animate({'top':'156px'});
	});

	$('.c_s_pic .hd .prev,.e_s_news .hd .prev').hover(function(){
		$(this).find('i').addClass('animated slideInRight');
	},function(){
		$(this).find('i').removeClass('animated slideInRight');
	});

	$('.c_s_pic .hd .next,.e_s_news .hd .next').hover(function(){
		$(this).find('i').addClass('animated slideInLeft');
	},function(){
		$(this).find('i').removeClass('animated slideInLeft');
	});

	$('.e_s_news .bd ul li a').hover(function(){
		$(this).find('i').addClass('animated slideInLeft');
	},function(){
		$(this).find('i').removeClass('animated slideInLeft');
	});

	$('.e_pub_news dl dt a').hover(function(){
		//$(this).find('div').addClass('color');
		$(this).find('img').addClass('animated flipInX');
	},function(){
		//$(this).find('div').removeClass('color');
		$(this).find('img').removeClass('animated flipInX');
	});

	$('.g ul li a').hover(function(){
		$(this).find('img').addClass('animated swing');
	},function(){
		$(this).find('img').removeClass('animated swing');
	});

	$('.i_b_2 ul.cr li').hover(function(){
		$(this).find('i').stop(true,true).animate({'top':'-24px'});
	},function(){
		$(this).find('i').stop(true,true).animate({'top':'0'});
	});

	$('.a_b_1 .fr ul.bk li.wechat').hover(function(){
		$(this).find('img').css({'display':'block'}).addClass('animated slideInUp');
	},function(){
		$(this).find('img').css({'display':'none'}).removeClass('animated slideInUp');
	});

	$('.d em').hover(function(){
		$(this).find('a').addClass('animated zoomIn');
	},function(){
		$(this).find('a').removeClass('animated zoomIn');
	});

	$('.d em').hover(function(){
		$(this).find('a').addClass('animated zoomIn');
	},function(){
		$(this).find('a').removeClass('animated zoomIn');
	});

	jQuery('.tp-banner').revolution({
		delay:5000,
		startwidth:1920,
		startheight:660,
        navigationStyle: "round",
        navigationHAlign: "center",
        navigationVAlign: "bottom",
		fullWidth:"off",
		forceFullWidth:"on"
	});
})