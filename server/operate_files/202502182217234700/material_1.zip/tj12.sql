select t1.department as '所属院系',t2.sname as '学生姓名',t2.sex as '性别',t2.birthday as '出生日期',t2.native as '籍贯'
from t_class t1 join t_student t2 on t1.classno = t2.classno;