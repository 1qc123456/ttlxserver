TYPE=VIEW
query=select `db_club`.`t_gs`.`gno` AS `社团编号`,count(distinct `db_club`.`t_gs`.`sno`) AS `总人数` from `db_club`.`t_gs` group by `db_club`.`t_gs`.`gno`
md5=9ef3103550dbc402954d17d64af08cf8
updatable=0
algorithm=0
definer_user=root
definer_host=localhost
suid=2
with_check_option=0
timestamp=2024-10-22 01:50:36
create-version=1
source=select gno as \'社团编号\',count(distinct sno) as \'总人数\'\nfrom t_gs\ngroup by gno
client_cs_name=utf8mb4
connection_cl_name=utf8mb4_general_ci
view_body_utf8=select `db_club`.`t_gs`.`gno` AS `社团编号`,count(distinct `db_club`.`t_gs`.`sno`) AS `总人数` from `db_club`.`t_gs` group by `db_club`.`t_gs`.`gno`
