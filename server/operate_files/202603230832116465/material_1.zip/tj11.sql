select bname as '书名',author as '作者',price as '价格'
from tb_book
where bno in ('b103','b105','b106')
order by price desc;