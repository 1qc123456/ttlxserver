TYPE=VIEW
query=select round(avg(`t1`.`age`),1) AS `平均年龄`,max(`t1`.`age`) AS `最大年龄`,min(`t1`.`age`) AS `最小年龄` from ((`db_booking`.`tb_student` `t1` join `db_booking`.`tb_reading` `t2` on((`t1`.`sno` = `t2`.`sno`))) join `db_booking`.`tb_book` `t3` on((`t2`.`bno` = `t3`.`bno`))) where (`t3`.`bname` = \'C语言程序设计\')
md5=0c8cb040670a8ab17bc9a71c80ed2484
updatable=0
algorithm=0
definer_user=root
definer_host=localhost
suid=1
with_check_option=0
timestamp=2025-04-29 01:08:25
create-version=1
source=select round(avg(`t1`.`age`),1) AS `平均年龄`,max(`t1`.`age`) AS `最大年龄`,min(`t1`.`age`) AS `最小年龄` from ((`tb_student` `t1` join `tb_reading` `t2` on((`t1`.`sno` = `t2`.`sno`))) join `tb_book` `t3` on((`t2`.`bno` = `t3`.`bno`))) where (`t3`.`bname` = \'C语言程序设计\')
client_cs_name=utf8mb4
connection_cl_name=utf8mb4_general_ci
view_body_utf8=select round(avg(`t1`.`age`),1) AS `平均年龄`,max(`t1`.`age`) AS `最大年龄`,min(`t1`.`age`) AS `最小年龄` from ((`db_booking`.`tb_student` `t1` join `db_booking`.`tb_reading` `t2` on((`t1`.`sno` = `t2`.`sno`))) join `db_booking`.`tb_book` `t3` on((`t2`.`bno` = `t3`.`bno`))) where (`t3`.`bname` = \'C语言程序设计\')
