select s.sname as '姓名',s.sex as '性别',s.age as '年龄',count(r.sno) as '借阅次数'
from tb_student s join tb_reading r on s.sno = r.sno
group by s.sname,s.sex,s.age
having count(r.sno) >= 2;