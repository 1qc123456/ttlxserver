select t1.sno as '学号',t2.sname as '姓名',t1.score as '分数'
from tb_score t1 join tb_student t2 on t1.sno = t2.sno
where cname = '英语' and score < 60;