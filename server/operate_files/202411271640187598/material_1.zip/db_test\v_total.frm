TYPE=VIEW
query=select `t2`.`sname` AS `姓名`,sum(`t1`.`score`) AS `总分` from (`db_test`.`tb_score` `t1` join `db_test`.`tb_student` `t2` on((`t1`.`sno` = `t2`.`sno`))) where (`t2`.`sex` = \'男\') group by `t2`.`sname` order by sum(`t1`.`score`) desc
md5=d000bbcbc86dd88604827f159fa8ccef
updatable=0
algorithm=0
definer_user=root
definer_host=localhost
suid=2
with_check_option=0
timestamp=2024-11-27 08:25:58
create-version=1
source=select t2.sname as \'姓名\',sum(t1.score) as \'总分\'\nfrom tb_score t1 join tb_student t2 on t1.sno = t2.sno\nwhere t2.sex = \'男\'\ngroup by t2.sname\norder by sum(t1.score) desc
client_cs_name=utf8mb4
connection_cl_name=utf8mb4_general_ci
view_body_utf8=select `t2`.`sname` AS `姓名`,sum(`t1`.`score`) AS `总分` from (`db_test`.`tb_score` `t1` join `db_test`.`tb_student` `t2` on((`t1`.`sno` = `t2`.`sno`))) where (`t2`.`sex` = \'男\') group by `t2`.`sname` order by sum(`t1`.`score`) desc
