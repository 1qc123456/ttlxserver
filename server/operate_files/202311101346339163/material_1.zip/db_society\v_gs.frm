TYPE=VIEW
query=select `t1`.`gno` AS `gno`,`t2`.`gname` AS `gname`,count(0) AS `COUNT(*)` from (`db_society`.`tb_gs` `t1` left join `db_society`.`tb_group` `t2` on((`t1`.`gno` = `t2`.`gno`))) group by `t1`.`gno`,`t2`.`gname`
md5=b7217bfc2a318aa26732a29dd83445ca
updatable=0
algorithm=0
definer_user=root
definer_host=localhost
suid=2
with_check_option=0
timestamp=2023-11-07 06:25:16
create-version=1
source=select t1.gno,t2.gname,COUNT(*) FROM tb_gs t1 LEFT JOIN tb_group t2 on t1.gno = t2.gno  GROUP BY t1.gno,t2.gname
client_cs_name=utf8mb4
connection_cl_name=utf8mb4_general_ci
view_body_utf8=select `t1`.`gno` AS `gno`,`t2`.`gname` AS `gname`,count(0) AS `COUNT(*)` from (`db_society`.`tb_gs` `t1` left join `db_society`.`tb_group` `t2` on((`t1`.`gno` = `t2`.`gno`))) group by `t1`.`gno`,`t2`.`gname`
