SELECT 
    d.dname AS 部门名称,
    SUM(s.basepay + s.overtime + s.allowance - s.insurance) AS total_salary
FROM 
    t_employee e
INNER JOIN 
    t_department d ON e.dno = d.dno
INNER JOIN 
    t_salary s ON e.eno = s.eno
WHERE 
    YEAR(s.salarydate) = 2024
GROUP BY 
    d.dname
ORDER BY 
    total_salary DESC;