TYPE=VIEW
query=select `t1`.`dname` AS `部门名称`,`t2`.`sex` AS `性别`,count(0) AS `人数` from (`db_salary`.`t_department` `t1` join `db_salary`.`t_employee` `t2` on((`t1`.`dno` = `t2`.`dno`))) where (`t2`.`sex` = \'男\') group by `t1`.`dname`,`t2`.`sex`
md5=020d9ed6ab0f9aafe4425e225e666f14
updatable=0
algorithm=0
definer_user=root
definer_host=localhost
suid=2
with_check_option=0
timestamp=2024-10-29 03:42:03
create-version=1
source=select t1.dname as \'部门名称\',t2.sex as \'性别\',count(*) as \'人数\'\nfrom t_department t1 join t_employee t2 on t1.dno = t2.dno\nwhere t2.sex = \'男\'\ngroup by t1.dname,t2.sex
client_cs_name=utf8mb4
connection_cl_name=utf8mb4_general_ci
view_body_utf8=select `t1`.`dname` AS `部门名称`,`t2`.`sex` AS `性别`,count(0) AS `人数` from (`db_salary`.`t_department` `t1` join `db_salary`.`t_employee` `t2` on((`t1`.`dno` = `t2`.`dno`))) where (`t2`.`sex` = \'男\') group by `t1`.`dname`,`t2`.`sex`
