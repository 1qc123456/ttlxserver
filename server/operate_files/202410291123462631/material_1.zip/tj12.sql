select d.dname as '部门名称',avg(timestampdiff(year,e.birthday,'2024-10-01')) as '平均年龄'
from t_department d join t_employee e on d.dno = e.dno
where d.dname = '行政部';