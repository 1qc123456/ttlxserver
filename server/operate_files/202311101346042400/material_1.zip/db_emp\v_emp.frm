TYPE=VIEW
query=select `t1`.`eno` AS `eno`,`t1`.`ename` AS `ename`,`t2`.`dname` AS `dname` from (`db_emp`.`tb_employee` `t1` left join `db_emp`.`tb_dept` `t2` on((`t1`.`deptno` = `t2`.`deptno`))) where (`t1`.`deptno` = \'D103\')
md5=85875bc6ef4f2d37edb7570efd4763dd
updatable=0
algorithm=0
definer_user=root
definer_host=localhost
suid=2
with_check_option=0
timestamp=2023-11-09 08:03:18
create-version=1
source=select t1.eno,t1.ename,t2.dname from tb_employee t1 LEFT JOIN tb_dept t2  on t1.deptno = t2.deptno  where t1.deptno = \'D103\'
client_cs_name=utf8mb4
connection_cl_name=utf8mb4_general_ci
view_body_utf8=select `t1`.`eno` AS `eno`,`t1`.`ename` AS `ename`,`t2`.`dname` AS `dname` from (`db_emp`.`tb_employee` `t1` left join `db_emp`.`tb_dept` `t2` on((`t1`.`deptno` = `t2`.`deptno`))) where (`t1`.`deptno` = \'D103\')
