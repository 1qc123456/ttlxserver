SELECT COUNT(*) AS '总人数'
FROM tb_employee e
JOIN tb_dept d ON e.deptno = d.deptno
WHERE d.dname = '市场部';