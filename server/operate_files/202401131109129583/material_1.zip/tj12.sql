SELECT t1.classId,t2.name, COUNT(*) from t_student t1 
	LEFT JOIN t_class  t2 
	on t1.classId = t2.id 
	GROUP BY classId
	HAVING COUNT(*) >= 5;