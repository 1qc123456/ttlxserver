TYPE=VIEW
query=select `t3`.`name` AS `教练姓名`,`t2`.`name` AS `班级名称`,`t1`.`name` AS `学员姓名`,`t1`.`age` AS `学员年龄` from ((`db_swim`.`t_student` `t1` join `db_swim`.`t_class` `t2` on((`t1`.`classId` = `t2`.`id`))) join `db_swim`.`t_coach` `t3` on((`t2`.`coachId` = `t3`.`id`))) where (`t3`.`name` = \'姜云熙\')
md5=ae92321370d32428a8dfdfb8f93bd167
updatable=1
algorithm=0
definer_user=root
definer_host=localhost
suid=2
with_check_option=0
timestamp=2024-01-12 08:45:05
create-version=1
source=SELECT t3.`name` as 教练姓名,t2.`name` 班级名称,t1.`name` 学员姓名,t1.age 学员年龄 from t_student t1 \n	INNER JOIN t_class t2  on t1.classid = t2.id\n	INNER JOIN t_coach t3\n	on t2.coachId = t3.id  \n	where t3.`name` = \'姜云熙\'
client_cs_name=utf8mb4
connection_cl_name=utf8mb4_general_ci
view_body_utf8=select `t3`.`name` AS `教练姓名`,`t2`.`name` AS `班级名称`,`t1`.`name` AS `学员姓名`,`t1`.`age` AS `学员年龄` from ((`db_swim`.`t_student` `t1` join `db_swim`.`t_class` `t2` on((`t1`.`classId` = `t2`.`id`))) join `db_swim`.`t_coach` `t3` on((`t2`.`coachId` = `t3`.`id`))) where (`t3`.`name` = \'姜云熙\')
