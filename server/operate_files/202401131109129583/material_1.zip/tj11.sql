SELECT t2.`name`,t1.`name`,t1.time from  t_class t1 
	LEFT JOIN t_student  t2 
	on t1.id = t2.classId  
	WHERE t2.`name` = '傅震南';