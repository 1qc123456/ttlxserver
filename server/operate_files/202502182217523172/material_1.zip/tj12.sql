select sname as '姓名',sex as '性别',birthday as '出生日期',native as '籍贯'
from t_student
where native = '湖北省' and year(birthday) = 2006
order by birthday;