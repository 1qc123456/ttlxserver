select role as '职务',count(role) as '数量'
from t_gs
group by role;