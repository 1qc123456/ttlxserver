TYPE=VIEW
query=select `db_club`.`t_student`.`native` AS `籍贯`,sum((case when (`db_club`.`t_student`.`sex` = \'男\') then 1 else 0 end)) AS `男生人数`,sum((case when (`db_club`.`t_student`.`sex` = \'女\') then 1 else 0 end)) AS `女生人数`,count(0) AS `总人数` from `db_club`.`t_student` group by `db_club`.`t_student`.`native`
md5=05bf75619e63ee38fcbac9fb07a4e578
updatable=0
algorithm=0
definer_user=root
definer_host=localhost
suid=2
with_check_option=0
timestamp=2024-10-21 01:51:38
create-version=1
source=select native as \'籍贯\',sum(case when sex = \'男\' then 1 else 0 end) as \'男生人数\',sum(case when sex = \'女\' then 1 else 0 end) as \'女生人数\',count(*) as \'总人数\'\nfrom t_student\ngroup by native
client_cs_name=utf8mb4
connection_cl_name=utf8mb4_general_ci
view_body_utf8=select `db_club`.`t_student`.`native` AS `籍贯`,sum((case when (`db_club`.`t_student`.`sex` = \'男\') then 1 else 0 end)) AS `男生人数`,sum((case when (`db_club`.`t_student`.`sex` = \'女\') then 1 else 0 end)) AS `女生人数`,count(0) AS `总人数` from `db_club`.`t_student` group by `db_club`.`t_student`.`native`
