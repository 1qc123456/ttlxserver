TYPE=VIEW
query=select `j`.`jobtitle` AS `职务名称`,count(`e`.`eno`) AS `人数` from (`db_salary`.`t_job` `j` join `db_salary`.`t_employee` `e` on((`j`.`jno` = `e`.`jobno`))) group by `j`.`jobtitle` order by count(`e`.`eno`) desc
md5=e9a4cfd8b154deedf9305a741e7e2124
updatable=0
algorithm=0
definer_user=root
definer_host=localhost
suid=2
with_check_option=0
timestamp=2024-10-14 08:16:52
create-version=1
source=select j.jobtitle as \'职务名称\',count(e.eno) as \'人数\'\nfrom t_job j join t_employee e on j.jno = e.jobno\ngroup by jobtitle\norder by count(e.eno) desc
client_cs_name=utf8mb4
connection_cl_name=utf8mb4_general_ci
view_body_utf8=select `j`.`jobtitle` AS `职务名称`,count(`e`.`eno`) AS `人数` from (`db_salary`.`t_job` `j` join `db_salary`.`t_employee` `e` on((`j`.`jno` = `e`.`jobno`))) group by `j`.`jobtitle` order by count(`e`.`eno`) desc
