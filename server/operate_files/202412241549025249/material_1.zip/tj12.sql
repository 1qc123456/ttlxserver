select d.dname as '部门名称',sum(s.basepay+s.overtime+s.allowance+s.insurance) as '工资总和'
from t_salary s join t_employee e on s.eno = e.eno
join t_department d on e.dno = d.dno
group by d.dname; 