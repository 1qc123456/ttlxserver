select ename as '姓名',sex as '性别',birthday as '生日' from t_employee
where year(birthday) >= 2000
order by birthday desc;