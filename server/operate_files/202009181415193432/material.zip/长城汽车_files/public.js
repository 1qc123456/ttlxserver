//导航条选择菜单
var timer = null;
$(".nav li").on({
    mouseenter: function(){
        $(".nav span").stop().animate({
            left: $(this).position().left + 50,
            width: $(this).width()
        })
        $(".nav").find(".downBox").stop().slideUp();
        $(this).find(".downBox").stop().slideDown();
        if($(this).hasClass("cars")){
            $(".chilid1").slideDown();
            $(".header").css("position","fixed")
            $(".header").css("top","0")
            $(".kv").css("margin-top","80px")
            $(".bugPub").css("margin-top","160px")
        }
        clearTimeout(timer);
    },
    mouseleave: function(){
        timer = setTimeout(function(){
            $(".nav span").animate({
                left: $(".nav li.active").position().left + 50,
                width: $(".nav li.active").width()
            })
            $(".nav").find(".downBox").hide();
            $(".chilid1").slideUp();

        },200)
    }
})
$(".carBox dt").on("click",function () {
    var _this=$(this)
    $('.carBox dd').slideUp()
    if(_this.hasClass("on")){
        _this.removeClass("on")
    }else{
        _this.addClass("on")
        _this.parents().siblings().find("dt").removeClass("on")
        _this.nextAll("dd").slideDown()
    }
})
// 辅助导航鼠标滑过
$(window).bind("scroll", function () {
    var sTop = $(window).scrollTop();
    var sTop = parseInt(sTop);
    if (sTop >= 800) {
        if (!$(".common-right-nav ul li.last").is(":visible")) {
            try {
                $(".common-right-nav ul li.last").slideDown();
            } catch (e) {
                $(".common-right-nav ul li.last").show();
            }
        }
    }
    else {
        if ($(".common-right-nav ul li.last").is(":visible")) {
            try {
                $(".common-right-nav ul li.last").slideUp();
            } catch (e) {
                $(".common-right-nav ul li.last").hide();
            }
        }
    }
});
// 辅助导航鼠标滑过
$(".common-right-nav").mouseover(function(){
    $(this).addClass("new-hover");
});
$(".common-right-nav").mouseout(function(){
    $(this).removeClass("new-hover");
    $(".qr-code-popup").removeClass('on-open');
});
$(".share-icon2").click(function(){
    $(".qr-code-popup").toggleClass('on-open');
});
$(".btn-go-top").on("click",function(){
    $("html,body").scrollTop(0)
});
$('.nav-big-menu .left-box a').mouseenter(function(event) {
    event.preventDefault();
    if ($(this).hasClass('active')) return;
    $(this).addClass('active').siblings('a').removeClass('active');
    $(this).parents('.left-box').next('.right-box').find('.content').eq($(this).index()).addClass('show').siblings('.content').removeClass('show');
});
//监测
$("a[data-event]").on("click",function () {
    var trackData = $(this).attr("data-event");
    if(trackData != ''){
        trackEvent(trackData);
        var tdTrack = trackData.split('_');
        tdEvent(tdTrack[0], tdTrack[1], '', '');
    }
})
//新闻摘要判断
var zhaiyao=$(".Abstract p").text()
console.log(typeof(zhaiyao))
if(zhaiyao==''){
    $(".Abstract").hide()
}