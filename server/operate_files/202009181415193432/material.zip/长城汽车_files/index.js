$(".banner ul li").hover(function () {
    var _this=$(this);
    var num=$(this).index()
    console.log(num)
    _this.addClass("active").siblings().removeClass("active")
})

$(".mainNews ul li").hover(function () {
    var _this=$(this);
    var num=$(this).index()
    console.log(num)
    $(".imgNews dd").eq(num).show().siblings().hide()
})
$(".footerRight .wx").on("click",function () {
    $(".wechat_erm").addClass("on")
})
$(".footerRight .wx").mouseout(function(){
    $(".wechat_erm").removeClass("on")
});