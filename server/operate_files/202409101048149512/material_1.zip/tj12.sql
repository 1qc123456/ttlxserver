select round(avg(age),2) as '平均年龄',max(age) as '最大年龄',min(age) as '最小年龄'
from t_student;