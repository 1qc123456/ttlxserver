select sname as '姓名',sex as '性别',age as '年龄'
from t_student
where age >= 16
order by age desc
limit 3;