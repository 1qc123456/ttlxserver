TYPE=VIEW
query=select count(`db_student`.`t_teacher`.`tid`) AS `教师人数`,ceiling(avg(`db_student`.`t_teacher`.`age`)) AS `平均年龄`,ceiling(avg(`db_student`.`t_teacher`.`salary`)) AS `平均薪资` from `db_student`.`t_teacher`
md5=942e0c635874cb6d324579ccbeabb4b2
updatable=0
algorithm=0
definer_user=root
definer_host=localhost
suid=2
with_check_option=0
timestamp=2024-09-10 02:55:16
create-version=1
source=select count(tid) as \'教师人数\',ceil(avg(age)) as \'平均年龄\',ceil(avg(salary)) as \'平均薪资\'\nfrom t_teacher
client_cs_name=utf8mb4
connection_cl_name=utf8mb4_general_ci
view_body_utf8=select count(`db_student`.`t_teacher`.`tid`) AS `教师人数`,ceiling(avg(`db_student`.`t_teacher`.`age`)) AS `平均年龄`,ceiling(avg(`db_student`.`t_teacher`.`salary`)) AS `平均薪资` from `db_student`.`t_teacher`
