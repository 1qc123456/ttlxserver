$(function() {
	$("#slider").responsiveSlides({
		/*auto: true,*/
                auto: false,
		pager: true,
		nav: true,
		speed: 500,
		namespace: "slide"
	});

	$("#slider1").responsiveSlides({
		auto: true,
		pager: true,
		nav: false,
		speed: 500,
		namespace: "slide"
	});

	$("#slider2").responsiveSlides({
		auto: true,
		pager: true,
		nav: false,
		speed: 500,
		namespace: "slide"
	});
});