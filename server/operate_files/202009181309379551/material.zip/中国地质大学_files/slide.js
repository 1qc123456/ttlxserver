$(function() {
	$('.navList>li').mousemove(function() {
		$(this).find('.subnav').slideDown(); //you can give it a speed
	});
	$('.navList>li').mouseleave(function() {
		$(this).find('.subnav').slideUp("fast");
	});
	$(".ksdh_btn").click(function() {
		if($('.kudh_sub').attr("class") == "kudh_sub") {
			$('.kudh_sub').attr("class", "kudh_sub db");
		} else {
			$('.kudh_sub').attr("class", "kudh_sub");
		}
	});

	$('.welList li').click(function(ev) {
		ev.stopPropagation();
		var isTrue = $(this).is('.on');

		if(isTrue) {
			$(this).find('dl').slideUp();
			//$(this).find('i').removeClass('jt_2');
			$(this).removeClass('on');
		} else {
			$(this).find('dl').slideDown();
			//$(this).find('i').addClass('jt_2');
			$(this).addClass('on');
		}
		$(this).siblings().removeClass('on');
		$(this).siblings().find('dl').slideUp();
	});

	$(document).click(function() {
		$('welList li').find('dl').slideUp();
		$('welList li').removeClass('on');
	})

});