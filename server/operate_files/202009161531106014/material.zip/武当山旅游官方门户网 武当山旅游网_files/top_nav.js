function gid(id)
{
	return document.getElementById(id);
}
function toalpha(id, opacity){
	if(opacity >=1 ){
		opacity = opacity / 100;
	}

	try{
		gid(id).style.opacity = opacity; 
	}catch(e){}
	try{
		if(gid(id).filters){
			gid(id).filters("alpha").opacity = opacity * 100;
		}
	}catch(e){}
}
function to_top (id, len) {
	gid(id).style.marginTop = len + 'px';
}

function get_alpha(id){
	var alpha = null;
	try{
		alpha = gid(id).style.opacity * 100; 
	}catch(e){}
	try{
		if(gid(id).filters){
			alpha = gid(id).filters("alpha").opacity;
		}
	}catch(e){}
	return alpha;
}



var init_opacity = 0;
var init_mt = -35;

var final_opacity = 100;
var final_mt = -10;

var run_sub_nav;


function run_nav() {
	if (init_mt < final_mt && init_opacity < final_opacity){
		toalpha('sub_nav', init_opacity += 4);
		to_top('sub_nav', init_mt += 1);
	}else{
		init_opacity = 0;
		init_mt = -35;
		clearInterval(run_sub_nav);
	}
}

function out_sub_nav() {
	change_all_event(0);
	var current_display = gid('sub_nav').style.display;
	var current_mt = gid('sub_nav').style.marginTop;
	var current_opacity = get_alpha('sub_nav');
	if(current_display == 'block' && current_mt == '-10px' && current_opacity == 100){
		//clearInterval(run_sub_nav);
	}else{
		toalpha('sub_nav', 0);
		gid('sub_nav').style.display = 'block';
		gid('sub_nav').style.marginTop = '-35px;'
		clearInterval(run_sub_nav);
		run_sub_nav = setInterval(function () {
			run_nav();
		}, 13);
	}
}



//0是取消所有事件   1是添加所有事件
function change_all_event(status){
	if (status){
		gid('main_nav').onmouseenter = function (){
			//console.log('进入了main_nav');
			out_sub_nav();
		}
	}else{
		gid('main_nav').onmouseenter = null;
	}
}


gid('main_nav').onmouseenter = function (){
	//console.log('进入了main_nav');
	out_sub_nav();
};

var sub_nav_status = 0;//subnav状态，0表示未显示，1表示已经显示
gid('main_nav').onclick = function (){
	//console.log('进入了main_nav');
	if (sub_nav_status) {
		gid('sub_nav').style.display = 'none';
		sub_nav_status = 0;
	}else{
		out_sub_nav();
		sub_nav_status = 1;
	}
	
};

gid('full_nav').onmouseleave = function () {
	//console.log('离开full_nav');
	gid('sub_nav').style.display = 'none';
	change_all_event(1);
};



