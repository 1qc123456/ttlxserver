select t2.name as '同学姓名',t1.score as '数学成绩'
from t_student t2 join t_score t1 on t2.id = t1.stuid
join t_subject t3 on t1.subid = t3.id
where t2.age >= 18 and t3.name = '数学' 
order by t1.score desc
limit 3;