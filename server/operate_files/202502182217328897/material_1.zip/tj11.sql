select t3.name as '科目名称',max(t1.score) as '最高分'
from t_score t1 join t_subject t3 on t1.subid = t3.id
group by t3.name;