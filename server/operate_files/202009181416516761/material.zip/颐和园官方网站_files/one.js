/**
 * Created by dbdb on 2017/4/17.
 */
//首页头部的隐藏与显示
$(function() {

 $(".jiantou").click(function () {
        $(".english").show();
    });


    $("#header_top").load("header.html")
    $(".header").hide();

    $(document).scroll(function() {
        var scrollTop = $(document).scrollTop() || $("body").scrollTop()
        if (scrollTop > 400) {
            $(".header").show();
        } else if (scrollTop < 400) {
            $(".header").hide();
        }
    });

    //    二维码显示
    $(".er_a li").hover(function() {
        $(this).find(".imgs").show().parent("li").siblings().find(".imgs").hide();
    }, function() {
        $(".imgs").hide();
    })

    //颐和资讯table切换
    $(".table_ul").click(function() {
        //alert(1)
        var i = $(this).index();
        //console.log(i)
        $(".table_content").eq(i).show().siblings().hide()
    });
    var index_html = "最新动态";
    $(".consult_table ul").click(function() {
        index_html = $(this).html();
        var index = $(this).index();
        $(".consult_content").eq(index).show().siblings().hide();
    });


    //颐和美图轮播
    var i = 0;

    function time() {
        i++;
        $(".pretty_content").stop().animate({ left: -i * 324 }, 500);
        if (i > $(".pretty_content ul").length - 3) {
            $(".pretty_content").stop().animate({ left: 0 }, 0);
            i = 0;
        }
    }
    var timer = setInterval(time, 3000);
    $(".pretty_wrapper").hover(function() {
        clearInterval(timer)
    }, function() {
        timer = setInterval(time, 3000);
    })


    //    颐和服务tab切换
    $(".table_ul").eq(0).click(function() {
        if ($(this).find("img").attr("src") == "images/icon_3.png") {
            $(this).find("img").attr({ "src": "images/sy_15.png" })
            $(".table_ul").eq(1).find("img").attr({ "src": "images/lun.png" })
            $(".table_ul").eq(2).find("img").attr({ "src": "images/sy_03.png" })
            $(".table_ul").eq(3).find("img").attr({ "src": "images/sy_06.png" })
            $(".table_ul").eq(4).find("img").attr({ "src": "images/sy_12.png" })
        } else {
            $(this).find("img").attr({ "src": "images/icon_3.png" })
        }
    })

    $(".table_ul").eq(1).click(function() {
        if ($(this).find("img").attr("src") == "images/lun.png") {
            $(this).find("img").attr({ "src": "images/sy_09.png" })
            $(".table_ul").eq(0).find("img").attr({ "src": "images/icon_3.png" })
            $(".table_ul").eq(2).find("img").attr({ "src": "images/sy_03.png" })
            $(".table_ul").eq(3).find("img").attr({ "src": "images/sy_06.png" })
            $(".table_ul").eq(4).find("img").attr({ "src": "images/sy_12.png" })
        } else {
            $(this).find("img").attr({ "src": "images/lun.png" })
        }
    })
    $(".table_ul").eq(2).click(function() {
        if ($(this).find("img").attr("src") == "images/sy_03.png") {
            $(this).find("img").attr({ "src": "images/sy_01.png" })
            $(".table_ul").eq(0).find("img").attr({ "src": "images/icon_3.png" })
            $(".table_ul").eq(1).find("img").attr({ "src": "images/lun.png" })
            $(".table_ul").eq(3).find("img").attr({ "src": "images/sy_06.png" })
            $(".table_ul").eq(4).find("img").attr({ "src": "images/sy_12.png" })
        } else {
            $(this).find("img").attr({ "src": "images/sy_03.png" })
        }
    })
    $(".table_ul").eq(3).click(function() {
        if ($(this).find("img").attr("src") == "images/sy_06.png") {
            $(this).find("img").attr({ "src": "images/icon_9.png" })
            $(".table_ul").eq(0).find("img").attr({ "src": "images/icon_3.png" })
            $(".table_ul").eq(1).find("img").attr({ "src": "images/lun.png" })
            $(".table_ul").eq(2).find("img").attr({ "src": "images/sy_03.png" })
            $(".table_ul").eq(4).find("img").attr({ "src": "images/sy_12.png" })
        } else {
            $(this).find("img").attr({ "src": "images/sy_06.png" })
        }
    })
    $(".table_ul").eq(4).click(function() {
        if ($(this).find("img").attr("src") == "images/sy_12.png") {
            $(this).find("img").attr({ "src": "images/icon_1.png" })
            $(".table_ul").eq(0).find("img").attr({ "src": "images/icon_3.png" })
            $(".table_ul").eq(1).find("img").attr({ "src": "images/lun.png" })
            $(".table_ul").eq(2).find("img").attr({ "src": "images/sy_03.png" })
            $(".table_ul").eq(3).find("img").attr({ "src": "images/sy_06.png" })
        } else {
            $(this).find("img").attr({ "src": "images/sy_12.png" })
        }
    })

    //    颐和服务下拉
    $("#sanjiao").click(function(ev) {
        ev.stopPropagation();
        $("#xiala").slideDown();
    });
    $(document).click(function() {
        $("#xiala").slideUp();
    })
    var indexx = 0;
    $("#xiala li").click(function() {
        $(".tab_title>span").html($(this).text());
        $("#xiala").slideToggle();
        indexx = $(this).index();
        $(".serive_im1 a").eq(indexx).show().siblings().hide();
        //$("#drag a").eq(indexx).find("img").click(function(){
        //     window.open("fangW.html#"+$(this).attr("src"));
        //});
    });
    //$("#drag a").eq(0).find("img").click(function(){
    //     window.open("fangW.html#"+$(this).attr("src"));
    //});


    //点击查看地理位置
    $(".wc").click(function() {
        var name = $(".spa1 ").text();
        window.open("map/map.html#name=1");
    });
    $(".lc").click(function() {
        var name = $(".spa2").text();
        window.open("map/map.html#name=2");
    });
    $(".ly").click(function() {
        var name = $(".spa3").text();
        window.open("map/map.html#name=3");
    });
    $(".dy").click(function() {
        var name = $(".spa4").text();
        window.open("map/map.html#name=4");
    });
    $(".jt").click(function() {
        var name = $(".spa5").text();
        window.open("map/map.html#name=5");
    });



    //颐和资讯消息分类

    $(".zlzc_title").click(function() {
        $("#ggyg").hide();
        $("#zlzc").show();
    });
    $(".ggyg_title").click(function() {
        $("#zlzc").hide();
        $("#ggyg").show();
    });

    $(".zxdt_title").click(function() {
        $("#zlzc").hide();
        $("#ggyg").hide();
    });

    //判断滚动条的高度
    $(".yllx").click(function() {
        var Hh = 890;
        window.open("/xnyh/index.htm#" + Hh);

    });


});


//获取当前的天气
// function findWeather() {
//     var cityUrl = 'http://int.dpool.sina.com.cn/iplookup/iplookup.php?format=js';
//     $.getScript(cityUrl, function(script, textStatus, jqXHR) {
//         var citytq = remote_ip_info.city; // 获取城市
//         var url = "http://php.weather.sina.com.cn/iframe/index/w_cl.php?code=js&city=" + citytq + "&day=0&dfc=3";
//         $.ajax({
//             url: url,
//             dataType: "script",
//             scriptCharset: "gbk",
//             success: function(data) {
//                 var _w = window.SWther.w[citytq][0];
//                 var _f = _w.f1 + "_0.png";
//                 if (new Date().getHours() > 17) {
//                     _f = _w.f2 + "_1.png";
//                 }
//                 var img = "<img width='16px' height='16px' src='http://i2.sinaimg.cn/dy/main/weather/weatherplugin/wthIco/20_20/" + _f +
//                     "' />";
//                 var tq = "颐和园周边天气" + " " + img + "&nbsp;&nbsp " + _w.s1 + "&nbsp;&nbsp" + _w.t1 + "℃～" + _w.t2 + "℃ " + "&nbsp;&nbsp" + _w.d1 + _w.p1 + "级";

//                 $('#weather').html(tq);
//             }
//         });
//     });
// }

// findWeather();
/*
$(document).ready(function() {
    var content = $('#zxdt_content');
    content.empty();
    $.get("api/ContentExt/getListChannelGroup", { groupname: '颐和资讯new', totalnum: 14, orderby: 'AddDate' },
        function(data) {
            data.forEach(function(element) {
                content.append("<a href='/contents/" + element.nodeId + "/" + element.id + ".html'><p>" + element.addDate.substring(0, 10) + " " + element.nodeName + " " + element.title + "</p></a>");
            }, this);
        },
        "json"
    );
});
*/

window.onload = function() {
    //获得当前的日期
    var data = new Date();
    var y = data.getFullYear();
    var m = data.getMonth() + 1;
    var d = data.getDate();
    var arr = ["星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六"];
    var dd = data.getDay();
    var div = document.getElementsByClassName("header_y")[0];
    div.innerHTML = "今天是" + y + "年" + m + "月" + d + "日" + "&nbsp;&nbsp;&nbsp" + arr[dd];
};