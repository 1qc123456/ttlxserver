console.log(window.location.host);

document.addEventListener("click", function(e) {
	console.log("gatherclikkk");
	var child = e.target;
	var selectors = []
	
	//过滤房山扫面点击数据
	if (e.offsetX<=0 || e.offsetY<=0) {
		//console.log("~0,0");
		return;
	}
	
	//待优化
	while (true) {
		var parent = child.parentElement;
		var children = parent.children;

		if (children.length > 1) {
			var index = gp_elemIndex(parent.children, child);
			selectors.push(child.localName + ":nth-child(" + index + ")");
		} else {
			selectors.push(child.localName);
		}
		
		if (parent.localName == "body")
			break;
		child = parent;
	}
	selectors = selectors.reverse();
	
	var $elem = $(document.querySelector(selectors.join(" >")));

	var x = parseInt(e.pageX - $elem.offset().left);
	var y = parseInt(e.pageY - $elem.offset().top);
	var width = parseInt($elem.width());
	var height = parseInt($elem.height());
	var selector = selectors.join(" >");
	//!!!不能使用location.href
	var href = window.location.origin + window.location.pathname;
	console.log({
		selector : selector,
		x : x,
		y : y,
		w : width,
		h : height,
		href : href
	});
	
	var gphost = $("#gpgatherclickinfojs").attr("src");
	gphost = gphost.slice(0,gphost.indexOf("/resource/js"));
	//console.log(gphost);
	/*$.post(
		gphost+"/api/clickpoint/gather", 
		{
			selector : selector,
			x : x,
			y : y,
			w : width,
			h : height,
			href : window.location.href
		}, 
		function(result) {
			console.log("ok")
			}
	);*/
	 $.ajax({
	    	type:"post",
	    	url:gphost+"/api/clickinfo/gather",
	    	//url:"http://localhost:8080/wm"+"/api/clickinfo/gather",
	    	dataType:"JSONP",
	    	data:{
				selector : selector,
				x : x,
				y : y,
				w : width,
				h : height,
				href : window.location.href
				//href : "http://www.qhjyks.com/"
			},
	    	success:function(resp){
	    		debugger;
	    		console.log(resp);
	    	}
	 });
});

function gp_elemIndex(children22, child) {

	for (var i = 0; i < children22.length; i++) {
		if (children22[i] === child) {
			return i + 1;
		}
	}
	return 0;
}