 $(function () {
        var myDate = new Date();
        var month=myDate.getMonth()+1;
        var time=month==4||month==8||month==11;
         time? $("#Tourist").show():$("#Tourist").hide();
       // Date? $("#public").show():$("#public").hide()；
    })