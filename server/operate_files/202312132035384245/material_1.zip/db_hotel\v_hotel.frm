TYPE=VIEW
query=select `t3`.`hname` AS `hname`,`t1`.`rname` AS `rname`,`t2`.`maxprice` AS `maxprice` from ((`db_hotel`.`t_room` `t1` left join (select `db_hotel`.`t_room`.`hid` AS `hid`,max(`db_hotel`.`t_room`.`price`) AS `maxprice` from `db_hotel`.`t_room` group by `db_hotel`.`t_room`.`hid`) `t2` on((`t1`.`hid` = `t2`.`hid`))) left join `db_hotel`.`t_hotel` `t3` on((`t1`.`hid` = `t3`.`hid`))) where (`t1`.`price` = `t2`.`maxprice`)
md5=1e4a10525d3f0d30200b7296d1d8020a
updatable=0
algorithm=0
definer_user=root
definer_host=localhost
suid=2
with_check_option=0
timestamp=2023-12-13 12:14:35
create-version=1
source=select t3.hname,t1.rname,t2.maxprice from t_room  t1 LEFT JOIN (\nselect hid,MAX(price) as maxprice from t_room group by hid) t2 on t1.hid = t2.hid  \nLEFT JOIN t_hotel t3 on t1.hid = t3.hid where t1.price = t2.maxprice
client_cs_name=utf8mb4
connection_cl_name=utf8mb4_general_ci
view_body_utf8=select `t3`.`hname` AS `hname`,`t1`.`rname` AS `rname`,`t2`.`maxprice` AS `maxprice` from ((`db_hotel`.`t_room` `t1` left join (select `db_hotel`.`t_room`.`hid` AS `hid`,max(`db_hotel`.`t_room`.`price`) AS `maxprice` from `db_hotel`.`t_room` group by `db_hotel`.`t_room`.`hid`) `t2` on((`t1`.`hid` = `t2`.`hid`))) left join `db_hotel`.`t_hotel` `t3` on((`t1`.`hid` = `t3`.`hid`))) where (`t1`.`price` = `t2`.`maxprice`)
