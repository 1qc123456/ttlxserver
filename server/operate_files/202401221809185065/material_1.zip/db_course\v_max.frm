TYPE=VIEW
query=select `t1`.`学号` AS `学号`,`t1`.`姓名` AS `姓名`,max(`t2`.`成绩`) AS `MAX(``成绩``)` from (`db_course`.`学生表` `t1` join `db_course`.`成绩表` `t2` on((`t1`.`学号` = `t2`.`学号`))) group by `t1`.`学号`
md5=2c292f55e58730b1f2eadca479baaa76
updatable=0
algorithm=0
definer_user=root
definer_host=localhost
suid=2
with_check_option=0
timestamp=2024-01-15 06:34:28
create-version=1
source=SELECT t1.`学号`,t1.`姓名`,MAX(`成绩`) FROM `学生表` t1 \n		INNER JOIN  `成绩表` t2 \n		ON t1.`学号` = t2.`学号` \n		GROUP BY t1.`学号`
client_cs_name=utf8mb4
connection_cl_name=utf8mb4_general_ci
view_body_utf8=select `t1`.`学号` AS `学号`,`t1`.`姓名` AS `姓名`,max(`t2`.`成绩`) AS `MAX(``成绩``)` from (`db_course`.`学生表` `t1` join `db_course`.`成绩表` `t2` on((`t1`.`学号` = `t2`.`学号`))) group by `t1`.`学号`
