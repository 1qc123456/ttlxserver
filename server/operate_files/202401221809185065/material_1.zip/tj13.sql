	select  t1.`学号`,t1.`姓名`,SUM(`成绩`) from `学生表` t1 
	INNER JOIN 成绩表 t2 
	on t1.`学号` = t2.`学号` 
	WHERE t1.`出生日期` BETWEEN '2005-01-01' AND '2005-06-30'
	GROUP BY t1.`学号`,t1.`姓名`;