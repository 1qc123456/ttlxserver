	select  t1.`班级`,CEIL(AVG(成绩)) from `学生表` t1 
	INNER JOIN 成绩表 t2 
	on t1.`学号` = t2.`学号`  
	GROUP BY t1.`班级`;