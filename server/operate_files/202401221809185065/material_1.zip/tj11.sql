SELECT t1.`学号`,t1.`姓名`,t1.`班级`,t2.`教师编号` from `学生表` t1  
	INNER JOIN `教师表` t2 
	on t1.`班级` = t2.`班级`   
	WHERE  t2.`课程ID` = 102;