TYPE=VIEW
query=select date_format(`t1`.`inbound_date`,\'%Y-%m\') AS `月份`,sum((case `t3`.`warehouse_name` when \'华中仓库\' then (`t1`.`quantity` * `t2`.`unit_price`) else 0 end)) AS `华中仓库`,sum((case `t3`.`warehouse_name` when \'首都仓库\' then (`t1`.`quantity` * `t2`.`unit_price`) else 0 end)) AS `首都仓库`,sum((case `t3`.`warehouse_name` when \'东海仓库\' then (`t1`.`quantity` * `t2`.`unit_price`) else 0 end)) AS `东海仓库`,sum((case `t3`.`warehouse_name` when \'钱塘仓库\' then (`t1`.`quantity` * `t2`.`unit_price`) else 0 end)) AS `钱塘仓库`,sum((case `t3`.`warehouse_name` when \'南方仓库\' then (`t1`.`quantity` * `t2`.`unit_price`) else 0 end)) AS `南方仓库`,sum((`t1`.`quantity` * `t2`.`unit_price`)) AS `总入库金额` from ((`db_wms`.`tb_inbound_order` `t1` left join `db_wms`.`tb_product` `t2` on((`t1`.`product_id` = `t2`.`product_id`))) left join `db_wms`.`tb_warehouse` `t3` on((`t3`.`warehouse_id` = `t1`.`warehouse_id`))) group by date_format(`t1`.`inbound_date`,\'%Y-%m\')
md5=3165dc67a2d55cfcb9644718021fe6e5
updatable=0
algorithm=0
definer_user=root
definer_host=localhost
suid=2
with_check_option=0
timestamp=2023-11-28 08:27:47
create-version=1
source=select  DATE_FORMAT(t1.inbound_date,\'%Y-%m\') \'月份\',\n	SUM(CASE t3.warehouse_name WHEN \'华中仓库\' THEN (t1.quantity * t2.unit_price) ELSE 0 END) as \'华中仓库\',\n	SUM(CASE t3.warehouse_name WHEN \'首都仓库\' THEN (t1.quantity * t2.unit_price) ELSE 0 END) as \'首都仓库\',\n	SUM(CASE t3.warehouse_name WHEN \'东海仓库\' THEN (t1.quantity * t2.unit_price) ELSE 0 END) as \'东海仓库\',\n	SUM(CASE t3.warehouse_name WHEN \'钱塘仓库\' THEN (t1.quantity * t2.unit_price) ELSE 0 END) as \'钱塘仓库\',\n	SUM(CASE t3.warehouse_name WHEN \'南方仓库\' THEN (t1.quantity * t2.unit_price) ELSE 0 END) as \'南方仓库\',\n	SUM(t1.quantity * t2.unit_price) \'总入库金额\'\n	from tb_inbound_order t1 \n	LEFT JOIN tb_product t2 on  t1.product_id = t2.product_id  \n	LEFT JOIN tb_warehouse t3 on t3.warehouse_id = t1.warehouse_id GROUP BY DATE_FORMAT(t1.inbound_date,\'%Y-%m\')
client_cs_name=utf8mb4
connection_cl_name=utf8mb4_general_ci
view_body_utf8=select date_format(`t1`.`inbound_date`,\'%Y-%m\') AS `月份`,sum((case `t3`.`warehouse_name` when \'华中仓库\' then (`t1`.`quantity` * `t2`.`unit_price`) else 0 end)) AS `华中仓库`,sum((case `t3`.`warehouse_name` when \'首都仓库\' then (`t1`.`quantity` * `t2`.`unit_price`) else 0 end)) AS `首都仓库`,sum((case `t3`.`warehouse_name` when \'东海仓库\' then (`t1`.`quantity` * `t2`.`unit_price`) else 0 end)) AS `东海仓库`,sum((case `t3`.`warehouse_name` when \'钱塘仓库\' then (`t1`.`quantity` * `t2`.`unit_price`) else 0 end)) AS `钱塘仓库`,sum((case `t3`.`warehouse_name` when \'南方仓库\' then (`t1`.`quantity` * `t2`.`unit_price`) else 0 end)) AS `南方仓库`,sum((`t1`.`quantity` * `t2`.`unit_price`)) AS `总入库金额` from ((`db_wms`.`tb_inbound_order` `t1` left join `db_wms`.`tb_product` `t2` on((`t1`.`product_id` = `t2`.`product_id`))) left join `db_wms`.`tb_warehouse` `t3` on((`t3`.`warehouse_id` = `t1`.`warehouse_id`))) group by date_format(`t1`.`inbound_date`,\'%Y-%m\')
