select t1.ename as '员工姓名',datediff(t2.stime,'2023-01-01') as '天数'
from t_employee t1 join t_salary t2 on t1.eid = t2.eid
where t1.ename = '小周';