TYPE=VIEW
query=select `t1`.`dname` AS `部门名称`,count(`t1`.`dname`) AS `部门人数`,sum(`t3`.`salary`) AS `部门总薪资` from ((`db_firm`.`t_department` `t1` join `db_firm`.`t_salary` `t3` on((`t1`.`did` = `t3`.`did`))) join `db_firm`.`t_employee` `t2` on((`t3`.`eid` = `t2`.`eid`))) group by `t1`.`dname`
md5=f951602872b55f97c67911b375ec469e
updatable=0
algorithm=0
definer_user=root
definer_host=localhost
suid=2
with_check_option=0
timestamp=2024-10-21 05:36:41
create-version=1
source=select distinct t1.dname as \'部门名称\',count(t1.dname) as \'部门人数\',sum(t3.salary) as \'部门总薪资\'\nfrom t_department t1 join t_salary t3 on t1.did = t3.did\njoin t_employee t2 on t3.eid = t2.eid\ngroup by t1.dname
client_cs_name=utf8mb4
connection_cl_name=utf8mb4_general_ci
view_body_utf8=select `t1`.`dname` AS `部门名称`,count(`t1`.`dname`) AS `部门人数`,sum(`t3`.`salary`) AS `部门总薪资` from ((`db_firm`.`t_department` `t1` join `db_firm`.`t_salary` `t3` on((`t1`.`did` = `t3`.`did`))) join `db_firm`.`t_employee` `t2` on((`t3`.`eid` = `t2`.`eid`))) group by `t1`.`dname`
