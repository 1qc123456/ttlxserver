select round(avg(salary),2) as '平均薪资',max(salary) as '最高薪资',min(salary) as '最低薪资'
from t_salary;