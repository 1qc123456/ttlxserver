SELECT c.name AS 班级名称, t.name AS 老师姓名, t.age AS 老师年龄, t.subject AS 科目, tc.ishead AS 是否是班主任   
FROM t_class c   
JOIN t_tea_class tc ON c.id = tc.c_id
JOIN t_teacher t on tc.t_id=t.id
WHERE tc.ishead='是'