TYPE=VIEW
query=select `t1`.`name` AS `name`,count(0) AS `num` from (`db_school`.`t_class` `t1` join `db_school`.`t_student` `t2` on((`t1`.`id` = `t2`.`c_id`))) group by `t1`.`name` order by `num` desc
md5=9be4f4d3ffdc5c365e4f8b2b364e5de1
updatable=0
algorithm=0
definer_user=root
definer_host=localhost
suid=1
with_check_option=0
timestamp=2024-02-26 05:31:41
create-version=1
source=select  t1.`name`,COUNT(*) num from t_class t1 JOIN t_student t2 on t1.id = t2.c_id  GROUP BY t1.`name` order by  num desc
client_cs_name=utf8mb4
connection_cl_name=utf8mb4_general_ci
view_body_utf8=select `t1`.`name` AS `name`,count(0) AS `num` from (`db_school`.`t_class` `t1` join `db_school`.`t_student` `t2` on((`t1`.`id` = `t2`.`c_id`))) group by `t1`.`name` order by `num` desc
