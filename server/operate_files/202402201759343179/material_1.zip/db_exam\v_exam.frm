TYPE=VIEW
query=select `t2`.`ename` AS `考生姓名`,`t2`.`sex` AS `性别`,`t2`.`tel` AS `考生联系方式`,`t2`.`examnum` AS `转考证号`,`t1`.`rname` AS `考场名称`,`t1`.`site` AS `考场地址` from (`db_exam`.`t_room` `t1` join `db_exam`.`t_examinee` `t2` on((`t1`.`rid` = `t2`.`rid`)))
md5=dbd037b6d3bb2d9d3b8f112a651ae021
updatable=1
algorithm=0
definer_user=root
definer_host=localhost
suid=2
with_check_option=0
timestamp=2024-01-20 07:02:49
create-version=1
source=SELECT\n	ename \'考生姓名\',\n	sex \'性别\',\n	tel \'考生联系方式\',\n	examnum \'转考证号\',\n	rname \'考场名称\',\n	site \'考场地址\' \nFROM\n	t_room t1\n	INNER JOIN t_examinee t2 ON t1.rid = t2.rid
client_cs_name=utf8mb4
connection_cl_name=utf8mb4_general_ci
view_body_utf8=select `t2`.`ename` AS `考生姓名`,`t2`.`sex` AS `性别`,`t2`.`tel` AS `考生联系方式`,`t2`.`examnum` AS `转考证号`,`t1`.`rname` AS `考场名称`,`t1`.`site` AS `考场地址` from (`db_exam`.`t_room` `t1` join `db_exam`.`t_examinee` `t2` on((`t1`.`rid` = `t2`.`rid`)))
