SELECT rname '考场名称',site '考场地址',tname '监考老师姓名',tel '联系方式'  from  t_room t1 
	INNER JOIN t_teacher t2 ON  t1.rid=t2.rid 
	WHERE t1.rname='402教室';