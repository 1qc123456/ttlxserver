SELECT ename '考生姓名',rname '考场名称',site '考场地址' from t_room t1 
	INNER JOIN t_examinee t2 ON t1.rid=t2.rid 
	WHERE t2.ename='陶宇宁';