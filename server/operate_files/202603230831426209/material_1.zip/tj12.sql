SELECT
    c.cid AS 汽车编号,
    c.cname AS 汽车名称,
    SUM(r.sale_quantity) AS 销售总数量
FROM tb_sales_records AS r
JOIN tb_cars AS c ON c.cid = r.cid
WHERE r.sale_date = '2025-01-06'
GROUP BY c.cid, c.cname;