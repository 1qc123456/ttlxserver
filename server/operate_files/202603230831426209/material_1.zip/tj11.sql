SELECT
    g.gname AS 汽车等级名称,
    c.cname AS 汽车名称,
    c.price_range AS 指导价范围
FROM tb_cars AS c
JOIN tb_grade AS g ON g.gid = c.gid
WHERE g.gname = 'C级';