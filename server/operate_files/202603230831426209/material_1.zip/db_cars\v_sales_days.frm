TYPE=VIEW
query=select `g`.`gname` AS `汽车等级名称`,sum((`r`.`sale_quantity` * `r`.`sale_price`)) AS `总销售额`,((to_days(\'2025-06-30\') - to_days(\'2025-04-01\')) + 1) AS `天数` from ((`db_cars`.`tb_sales_records` `r` join `db_cars`.`tb_cars` `c` on((`c`.`cid` = `r`.`cid`))) join `db_cars`.`tb_grade` `g` on((`g`.`gid` = `c`.`gid`))) where (`r`.`sale_date` between \'2025-04-01\' and \'2025-06-30\') group by `g`.`gid`,`g`.`gname` order by sum(`r`.`sale_quantity`) desc limit 4
md5=8338623f0866bf742fd00bab9d95eb33
updatable=0
algorithm=0
definer_user=root
definer_host=localhost
suid=1
with_check_option=0
timestamp=2025-11-19 04:03:14
create-version=1
source=select `g`.`gname` AS `汽车等级名称`,sum((`r`.`sale_quantity` * `r`.`sale_price`)) AS `总销售额`,((to_days(\'2025-06-30\') - to_days(\'2025-04-01\')) + 1) AS `天数` from ((`tb_sales_records` `r` join `tb_cars` `c` on((`c`.`cid` = `r`.`cid`))) join `tb_grade` `g` on((`g`.`gid` = `c`.`gid`))) where (`r`.`sale_date` between \'2025-04-01\' and \'2025-06-30\') group by `g`.`gid`,`g`.`gname` order by sum(`r`.`sale_quantity`) desc limit 4
client_cs_name=utf8mb4
connection_cl_name=utf8mb4_general_ci
view_body_utf8=select `g`.`gname` AS `汽车等级名称`,sum((`r`.`sale_quantity` * `r`.`sale_price`)) AS `总销售额`,((to_days(\'2025-06-30\') - to_days(\'2025-04-01\')) + 1) AS `天数` from ((`db_cars`.`tb_sales_records` `r` join `db_cars`.`tb_cars` `c` on((`c`.`cid` = `r`.`cid`))) join `db_cars`.`tb_grade` `g` on((`g`.`gid` = `c`.`gid`))) where (`r`.`sale_date` between \'2025-04-01\' and \'2025-06-30\') group by `g`.`gid`,`g`.`gname` order by sum(`r`.`sale_quantity`) desc limit 4
